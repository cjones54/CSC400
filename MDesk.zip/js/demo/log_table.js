// Call the dataTables jQuery plugin
$(document).ready(function() {
    $('#dataTable').DataTable({
        "order": [[ 0, "desc" ]],

        "scrollY":        "400px",
        "overflow": 'scroll',
        "scrollCollapse": true,
        "paging":         false
    });
});