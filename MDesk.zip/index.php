<?php
//echo date("Y/m/d");
//echo 'Current PHP version: ' . phpversion();
$page_id = "main";
$_SERVER['PHP_SELF'] = "/";

include_once "Pages/Includes/includes.php";
include_once "Pages/Includes/Parts/slide_show.php";
echo $header;


?>


<body id="page-top"  >

<!-- Page Wrapper -->
<div id="wrapper">

    <?php
    //side navbar defined in /php/mainHeader
    echo $navbar;

    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == true){
            echo $topbar;
        }
        ?>
        <!-- Begin Page Content -->
        <div class="container-fluid ">
                <?php

                    echo $contentHeader; //edit in php/mainHeader.php
                    echo $rowstart;
                        echo $cards;
                    echo $rowend;

                    echo $rowstart;
                        echo $containerstart;
                            echo $slide_show;
                            echo pageScripts("slide");
                        echo $containerstop;
                    echo $rowend;
                    //echo $slide_show;
                ?>
        </div><!-- /.container-fluid -->
    </div><!-- End of Content Wrapper -->
</div><!-- End of Main Content - wrapper -->

<?php
    echo $footer;
?>

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php
echo $logout;
echo pageScripts("default");
?>

</body>

</html>
