<?php
$page_id = "user_activity";
//$_SERVER['PHP_SELF'] = "/user_activity";
include_once "Includes/includes.php";
validateLogin($_SESSION['Logged In']);

echo $header;

?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <?php
    //side navbar defined in /php/mainHeader
    echo $navbar;
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == true){
            echo $topbar;
        }
        ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
            <?php
            echo $contentHeader; //edit in php/mainHeader.php

            echo $rowstart;
            echo $useractivitytable;


            echo $rowend;

            ?>

        </div>


    </div>
    <!-- /.container-fluid -->

</div><!-- End of Main Content - wrapper -->


<!-- Footer -->
<?php
echo $footer;
?>
<!-- End of Footer -->


<!-- End of Content Wrapper -->


<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<?php
echo $logout;
echo pageScripts("default");
echo pageScripts("table");
?>

</body>

</html>
