<?php
$page_id = 'login';
include_once "Includes/includes.php";
include_once "Includes/Parts/authentication.php";

echo $header;

if(isset($_SESSION['Logged In'])){

    header("Location: /TeamDashboard");
}else{

?>
<body class="bg-gradient-primary">
    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                    </div>
                                    <form class="user" action="<?php echo $_SERVER['PHP_SELF']?>" method="post" id="loginform">
                                        <div class="form-group">

                                            <input type="email" class="form-control form-control-user" name="userEmail" value ="<?php echo $userEmail ?>" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                                            <?php
                                            echo $emailError;
                                            ?>
                                        </div>

                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" name="userPassword" value ="<?php echo $password ?>" placeholder="Password">
                                            <?php
                                            echo $errorPassword;
                                            ?>
                                        </div>
                                        <div class="form-group">


                                            <?php
                                            if(!isset($_SESSION['real_user']) && !$_SESSION['real_user']) {
                                                echo "<hr>";
                                                echo $captcha_script;
                                                echo $captcha_form;
                                                echo $statusMsg;
                                            }

                                            ?>
                                        </div>
                                        <hr>
                                            <input name='submit' type = "submit" value = "Login" class="btn btn-primary btn-user btn-block">
                                        <hr>
                                    </form>
                                    <form class = "user" action="/">
                                        <input  type = "submit" value="Go Back" class="btn btn-primary btn-user btn-block">
                                    </form>

                                    <hr>
<!--                                    <div class="text-center">-->
<!--                                        <a class="small" href="#">Forgot Password?</a>-->
<!--                                    </div>-->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <?php
    }
    echo pageScripts("default");
    ?>

</body>

</html>


