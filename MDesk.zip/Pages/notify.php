<?php
//Create a SQL query script that updates the echoed variables for notifications
include_once 'Includes/DataLayer/SQLinterface.php';

$q = $_POST["q"];

function get_alerts($connect){

    if ($connect->connect_error)
    {
        die("Connection failed1: " . $connect->connect_error);

    } else {


        $sql = "SELECT * FROM MDesk.alerts WHERE recipient_id='22' AND unread='1';";
        $res = mysqli_query($connect, $sql);
        $count = 0;
        while ($row = mysqli_fetch_assoc($res)) {
            $count +=1;
        }
        //$result;
        $connect->close();
        return $count;


    }
}


$notificationCtr = 0;



$unreadEmailCtr = 0;



$timesinceRec = 0;

$test = "" .get_alerts(startConn());

echo $test;