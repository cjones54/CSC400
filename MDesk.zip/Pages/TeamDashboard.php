<?php
$page_id = "dashboard";
$_SERVER['PHP_SELF'] = "/TeamDashboard";
include_once "Includes/includes.php";
validateLogin($_SESSION['Logged In']);

echo $header;

?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <?php
    //side navbar defined in /php/mainHeader
    echo $navbar;
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == true){
            echo $topbar;

        }

        ?>


        <!-- Begin Page Content -->
        <div class="container-fluid">
            <?php
            echo $contentHeader; //edit in php/mainHeader.php

            echo $rowstart;
            echo $ticketTable;

            echo $rowend;

            ?>



        </div>
    </div>
</div>
    </div>


</div>
<?php
echo $footer;
?>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<?php
echo $logout;
echo pageScripts("Default");
echo pageScripts("table");
?>

</body>

</html>
