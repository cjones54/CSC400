<?php

include_once "Includes/includes.php";
if (isset($_SESSION['team_user'])) {
    endSession();



    header("Location: /");
} else {


    header("Location: /login");
}