<?php
$page_id = "settings";
$_SERVER['PHP_SELF'] = "/Settings";
$_POST['confirmation'] = false;
$confirmation = false;
include_once "Includes/includes.php";
validateLogin($_SESSION['Logged In']);

echo pageScripts("default");

echo $header;
?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <?php
    //side navbar defined in /php/mainHeader
    echo $navbar;
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == true){
            echo $topbar;
        }
        ?>
        <!-- Begin Page Content -->

            <div class="container-fluid">
                <?php
                echo $contentHeader; //edit in php/mainHeader.php
                ?>
                <div class="col-xl-10 col-lg-10 col-md-10" >
                    <div class="card o-hidden border-0 shadow-lg my-2">
                        <div class="card-body p-2">
                            <!-- Nested Row within Card Body -->

                                    <div class="row justify-content-center">
                                        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10" >
                                                <div class="card-header py-3 justify-content-between">

                                                        <table class="table" cellspacing="0">
                                                        <tr>
                                                            <td>
                                                                <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2" onclick="openPage('User')" id="defaultOpen" value="User Management">
                                                            </td>
                                                            <td>
                                                                <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2"  onclick="openPage('Customization')" value="Customizations">
                                                            </td>
                                                            <td>
                                                                <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2"  onclick="openPage('Data')"  value="Data">
                                                            </td>
                                                            <td>
                                                                <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2" onclick="openPage('Placeholder')"  value="Placeholder">
                                                            </td>
                                                        </tr>
                                                        </table>

                                                </div>
                                        </div>
                                    </div>
                            <?php
                            echo $rowstartjustify;
                            ?>

                                        <div id="User" class="tabcontent col">

                                            <table class="table" cellspacing="0">
                                                <tr>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2" onclick="openPage('User')" id="defaultOpen" value="User Management">
                                                    </td>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2"  onclick="openPage('Customization')" value="Customizations">
                                                    </td>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2"  onclick="openPage('Data')"  value="Data">
                                                    </td>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2" onclick="openPage('Placeholder')"  value="Placeholder">
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>


                                        <div id="Customization" class="tabcontent">

                                                <div class="text-black-50">
                                               Test
                                                </div>
                                        </div>



                                        <div id="Data" class="tabcontent col">
                                            <table class="table" cellspacing="0">
                                                <tr>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2" onclick="openPage('User', this)" id="defaultOpen" value="User Management">
                                                    </td>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2"  onclick="openPage('Customization', this)" value="Customizations">
                                                    </td>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2"  onclick="openPage('Data', this)"  value="Data">
                                                    </td>
                                                    <td>
                                                        <input type="button" class="btn-sm btn-primary btn-user btn-block mb-2" onclick="openPage('Placeholder', this)"  value="Placeholder">
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>

                                        <div id="Placeholder" class="tabcontent col">

                                            <h3>Placeholder</h3>
                                            <p>Placeholder</p>

                                        </div>
                                        <?php
                                        echo $rowend;
                                            ?>

                        </div>
                    </div>
                </div>

            </div>
    </div>




</div>


<?php
echo $footer;
?>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<script>
    function openPage(pageName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("btn-sm");
        // for (i = 0; i < tablinks.length; i++) {
        //     tablinks[i].style.backgroundColor = "";
        // }
        document.getElementById(pageName).style.display = "block";

    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
</script>

<?php
echo $logout;
echo pageScripts("default");
?>

</body>

</html>
