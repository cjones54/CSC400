<?php
//nclude_once '/Pages/Includes/DataLayer/SQLinterface.php';
$num=$_POST["TNum"];
function startConn(){
    $host = "localhost";
    $db = "MDesk";
    $username = "dev";
    $password = 'P@$$word12';

    $conn = new mysqli($host, $username, $password, $db);

    return $conn;
}

function get_comment($fields, $connect)
{
    if ($connect->connect_error) {
        die("Connection failed1: " . $connect->connect_error);
    } else {

        $num = ltrim($fields, "0");
        $sql = "SELECT * FROM MDesk.ticket_logs WHERE ticket_ref='$fields' AND team_only='0' ORDER BY datetime DESC;";

        if (!$connect->query($sql)) {
            die("Connection failed @ get: " . $connect->connect_error);
        } else {

            $res = mysqli_query($connect, $sql);
            $result = "";
            $first_row = true;
            while ($row = mysqli_fetch_assoc($res)) {
                if ($first_row) {
                    $result .= "<tr class='bg-gray-200 border-info'><td class='' style='width: 10%'>" . $row['datetime'] . "</td><td>" . $row['comment'] . "</td><td class='' style='width: 15%'>" . $row['sender'] . "</td></tr>";
                    $first_row = false;
                } else {
                    $result .= "<tr><td class='' style='width: 10%'>" . $row['datetime'] . "</td><td>" . $row['comment'] . "</td><td class='' style='width: 15%'>" . $row['sender'] . "</td></tr>";
                }
            }

            $connect->close();
            return $result;
        }
    }
}
$returned_val = get_comment($num, startConn());
echo $returned_val;
