<?php
$page_id = "ticket_page";




include_once "Includes/includes.php";
require_once "manage/ticket_updating.php";
validateLogin($_SESSION['Logged In']);

echo pageScripts("default");
echo $header;

?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <?php
    //side navbar defined in /php/mainHeader
    echo $navbar . pageScripts("default");
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == true){
            echo $topbar;
        }

        ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <?php
                echo $contentHeader; //edit in php/mainHeader.php

                echo $rowstart;

                ?>



                    <div class="col-lg-6">
                        <?php
                        echo $rowstart //. "<div class=\"col-6\">";
                        ?>
                        <!-- Circle Buttons -->
                            <div class="card shadow w-100 mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Details for ticket: <?php echo $t_id ?></h6>
                                </div>
                                <div class="card-body">

                                <?php

                                echo $ticket_info_card;
                                             ?>


                                </div>
                            </div>

                        <?php //"</div>" .
                        echo  $rowend . $rowstart;
                        ?>


                        <div class="card shadow w-100 mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Add Work Notes</h6>
                            </div>
                            <div class="card-body">
                                <?php
                                echo $team_input;
                                ?>
                            </div>
                        </div>
                </div>
                <?php
                echo $rowend;
                ?>

                    <div class="col-lg-6">

                        <div class="card shadow w-100 mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Logs</h6>
                            </div>
                            <div class="card-body">
                                <div class='col-lg m-2 table-responsive'>
                                    <?php
                                        echo $_SESSION['log'] ;
                                    ?>
                                </div>
                            </div>
                        </div>
                        <?php


                        ?>
                    </div>

                </div>



  <?php
  echo $rowend;
 ?>



            </div>
        </div>
    </div>
</div>


</div>
<?php
echo $footer;
?>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<?php
echo $logout;
echo pageScripts("default");
echo pageScripts('log');
?>

</body>

</html>
