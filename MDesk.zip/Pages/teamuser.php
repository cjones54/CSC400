<?php
echo "This is a profile page";
