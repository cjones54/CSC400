<?php
include_once 'Pages/Includes/DataLayer/SQLinterface.php';
$new_user = array ();

function newuser($conn, $username, $password, $new)
{

    $password = password_hash($new[3], PASSWORD_DEFAULT);

    if ($conn->connect_error)
    {
        die("Connection failed1: " . $conn->connect_error);
    } else {

        $sql = "insert into MDesk.users (lname, fname, usrname, password, email, ticket_count, last_login, failed_logins, password_last_set) values ('$new[0]', '$new[1]', '$new[2]', $password, '$new[4]', 0, CURRENT_TIMESTAMP, 0, CURRENT_TIMESTAMP);";

        if(!$conn->query($sql))
        {
            die("Connection failed2: " . $conn->connect_error);
        } else {
            //$sql = "SELECT * FROM work_tickets WHERE ORDER BY TNum DESC LIMIT 1;";

            echo "Input successful";
        }
    }
}
//newuser(startConn(), $username, $password, $new_user);