<?php
//include_once 'Pages/Includes/DataLayer/SQLinterface.php';



function get_comment($fields, $connect) {

    if ($connect->connect_error)
    {
        die("Connection failed1: " . $connect->connect_error);
    } else {

        $num = ltrim($fields, "0");
        $sql = "SELECT * FROM MDesk.ticket_logs WHERE ticket_ref='$num'  ORDER BY datetime DESC ;";

        if(!$connect->query($sql))
        {
            die("Connection failed @ get: " . $connect->connect_error);
        } else {

            $res = mysqli_query($connect, $sql);
            $result = "<table class=\"table table-bordered rounded\" id=\"dataTable\" cellspacing=\"0\"><thead>
                        <tr class='bg-gradient-dark text-gray-200' >
                            <th>Timestamp</th> 
                            <th>Comment</th>
                            <th>From</th>                            
                        </tr>
                    </thead>
                    <tfoot><tr></tr></tfoot>
                    <tbody>";
            $first_row = true;
            $ctr = 0;
            while ($row = mysqli_fetch_assoc($res)) {
                if ($first_row) {
                    $result .= "<tr class='bg-gray-200 border-info'><td class='' style='width: 10%'>" . $row['datetime'] . "</td><td>" . $row['comment'] . "</td><td class='' style='width: 15%'>" . $row['sender'] . "</td></tr>";
                    $first_row = false;
                    $ctr += 1;
                } else {
                    $result .= "<tr><td class='' style='width: 10%'>" . $row['datetime'] . "</td><td>" . $row['comment'] . "</td><td class='' style='width: 15%'>" . $row['sender'] . "</td></tr>";

                }
            }
            if($ctr < 1){
                $result .= "<tr class='border'><td class='border-0' style='width: 15%'>There are no logs</td></tr>";
            }
            $result .= "</tbody>
                  </table>";
            $connect->close();
            return $result;
        }
    }
}


function check_resubmit($num, $comment, $sender, $conn)
{
    $sql = "SELECT * FROM MDesk.ticket_logs WHERE ticket_ref='$num' ORDER BY datetime DESC LIMIT 1 ;";
    if (!$conn->query($sql)) {

        return true;
        //die("Connection failed1: " . $conn->connect_error);
    } else {
//        echo "<br>Checking";
        $res = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($res);
//echo "<br> Checking";
//        echo "<br>" . $row['sender'];
//        echo "<br>" . $row['comment'];
        if (($row['sender'] == $sender) && ($row['comment'] == $comment)) {
//             echo "<br> Repeated Comment";
            return true;
        } elseif ($comment =="") {
//             echo "<br> No Comment";

            return "Empty Comment";
        }
       else {
//            echo "<br> new Comment";
            return false;
        }
    }
}


function add_comment($fields, $connect)
{   $num = ltrim($fields[0], "0");
    if ($connect->connect_error) {
        return "ERROR";
    } else {
        $check = check_resubmit($num, $fields[1], $fields[2], $connect);
        if ($check == "Closed"){

            return true;
        } else {
            if ($check) {
                // echo "Repeat";
                $connect->close();
                return true;
            } else {
                $sql = "insert into MDesk.ticket_logs (ticket_ref, comment, sender, action_cost, team_only, datetime) values ('$num', '$fields[1]', '$fields[2]', '$fields[3]', '$fields[4]', CURRENT_TIMESTAMP());";




                $connect->query($sql);
                $connect->close();
                return false;
            }
        }
    }
}

function team_close($fields, $connect)
{
    if ($connect->connect_error) {
        die("Connection failed1: " . $connect->connect_error);
    } else {
        $date = date_format($fields[3], "Y/m/d");
        $date1 = date("Y/m/d");
        $days_open = date_diff($date, $date1);
        $num = ltrim($fields[0], "0");

        $sql1= "UPDATE MDesk.work_tickets SET status = 'closed',  closed = CURRENT_TIMESTAMP() WHERE TNum = '$num';";

            if (!$connect->query($sql1)) {
                //die("Connection failed when updating ticket status: " . $connect->connect_error);
                return "Error";
            } else {
                $connect->close();
                return true;
            }

        }

}


function assign($id, $rep, $fname, $connect){
    //$time = date_timestamp_get($id['opened']);
    //echo 'Time '. $time . '<br>';
//    $date = date_format(date("Y/m/d", $id['opened']));
//
//    echo $date .'<br>';
//    $date1 = date_format(date(),"Y/m/d");
//    echo $date1 .'<br>';
//    $days_open = date_diff($date, $date1);
//
//    echo $days_open;

    $num = ltrim($id['TNum'], "0");
    $namestring = 'Ticket Assigned to: ' . $fname;

//    $check = "SELECT * FROM MDesk.ticket_logs WHERE ticket_ref='$num' ORDER BY datetime DESC LIMIT 1;";
//
//    if (!$connect->query($check)){
//        die("Connection failed @ add: " . $connect->connect_error);
//    } else {
//        while($row = $connect->fetch($check)){
//            if(($row['sender'] == 'SYSTEM') && ($row['comment'] == $namestring)){
//                return 1;
//            }
//        }
//    }

    $sql = "UPDATE MDesk.work_tickets SET assignee_id = '$rep', assignee = '$fname', date_assigned = CURRENT_TIMESTAMP WHERE TNum = '$num';";
    $sql1 = "insert into MDesk.ticket_logs (ticket_ref, comment, sender, action_cost, team_only, datetime) values ('$num', ' $namestring' , 'SYSTEM', '0', '0', CURRENT_TIMESTAMP());";

    if(($connect->query($sql)) && ($connect->query($sql1))){
        $connect->close();
        return 1;
    } else {
        $error = "There was an error processing the action [PAGE ID: TICKET ASSIGNMENT]"  . '<br>';
        echo $id[0] . '<br>' . $id[1] . '<br>';
        echo $sql . '<br>';
        echo $sql1 . '<br>';
        echo $error;
        $connect->close();
        return 0;
    }
}

function load_tick($fields, $connect)
{
    if ($connect->connect_error)
    {
        return false;
        //die("Connection failed1: " . $connect->connect_error);
    } else {
//       echo "||ticket no. " . ltrim($fields[2], "0");
//        echo "||email :" . $fields[0] . "|||";
        $num = ltrim($fields, "0");
        //$sql = "SELECT * FROM MDesk.work_tickets WHERE TNum='$num' AND email='$fields[0]';";
        $sql = "SELECT * FROM MDesk.work_tickets LEFT JOIN MDesk.T_Category ON work_tickets.category = T_Category.Category_ID WHERE TNum='$num';";
        if(!$connect->query($sql))
        {
            echo "UHOH";
            return false;
            //die("Connection failed2: " . $connect->connect_error);
        } else {
            //$sql = "SELECT * FROM work_tickets WHERE ORDER BY TNum DESC LIMIT 1;";
            $res = mysqli_query($connect, $sql);

            $result = mysqli_fetch_assoc($res);
            if($result['email'] == ""){
                return false;
            } else {
                if ($result['status'] == 'open') {
                    $result['status'] = 'Open';
                } else {
                    $result['status'] = 'Closed';
                }
                $phone = substr($result['phone'], 0, 3) . " . " . substr($result['phone'], 3, 3) . " . " . substr($result['phone'], 6, 4);
                $result['phone'] = $phone;
                return $result;
            }
        }
    }
}



function add_work ($id, $connect, $text, $cost){

}

function reopen_ticket ($fields, $connect){
    if ($connect->connect_error) {
        return false;
    } else {
//        $date = date_format($fields[3], "Y/m/d");
//        $date1 = date("Y/m/d");
//        $days_open = date_diff($date, $date1);
        $num = ltrim($fields[0], "0");

        $sql1= "UPDATE MDesk.work_tickets SET status = 'open',  closed = CURRENT_TIMESTAMP() WHERE TNum = '$num';";

        if (!$connect->query($sql1)) {
            //die("Connection failed when updating ticket status: " . $connect->connect_error);
            return "Error";
        } else {
            $connect->close();
            return true;
        }

    }

}

if (!isset($_POST['assigned'])) {

    $assignment = $_POST['assignment'];
    //echo $assignment;
}
if (isset($_POST['t_id'])) {

    $t_id = $_POST['t_id'];
    if (!isset($_POST['num'])) {
    $_POST['num'] = $t_id;}
    //echo $assignment;
}
if (isset($_POST['num'])){
    $t_id=$_POST['num'];
}

if ((isset($_POST['assignment'])) && ($_POST['assignment'] == '50') ){
    $assigned = assign($_POST['t_id'], $_SESSION['user_id'], $_SESSION['fname'], startConn());
    if ($assigned == 1) {
        $ticket = load_tick($t_id, startConn());
        $t_id = $ticket['TNum'];
        $assignment = '25';
        $_POST['assigned'] = '50';
        unset($_POST['assignment']);
        //echo 'assigned';
    } else {
    $assignment = '50';

    }
//}
} elseif (isset($_POST["assignment"]) && ($_POST["assignment"] == 'comment')){

    if (!isset($_POST['workorder'])){
        $_POST['cost'] = "0.00";

    } else {
        $_POST['viewonly'] = 1;
        $comment = "Name: ".$_POST['poc']. "<br>Contact:  ".$_POST['contact']. "<br>Cost: $".$_POST['cost'] . "<br>".$_POST['comments'];
        $_POST['comments']  = $comment;
    }
    if (!isset($_POST['viewonly'])){
        $_POST['viewonly'] = 0;
    } else{
        $_POST['comments'] .= "<br> (TEAM VIEW ONLY)";
    }


    $fields = array($_POST['num'], $_POST['comments'], $_POST['sender'], $_POST['cost'], $_POST['viewonly']);

    add_comment($fields, startConn());
    $ticket = load_tick($_POST['num'], startConn());
    $t_id = $ticket['TNum'];

} elseif (($_POST['status'] == "Open") && ($_POST["act"]== 'close')){

    $fields = array($_POST['num'], $_SESSION['fname']);


    $status = team_close($fields, startConn());
    if ($status) {
        $fields = array($_POST['num'], "Ticket Closed", $_POST['sender'], "0", "0");
        add_comment($fields, startConn());
        $ticket = load_tick($_POST['num'], startConn());
        $t_id = $ticket['TNum'];
    }
} elseif (($_POST['status'] == "Closed") && ($_POST["act"]== 'reopen')){

    $fields = array($_POST['num'], $_SESSION['fname']);


    $status = reopen_ticket($fields, startConn());
    if ($status) {
        $fields = array($_POST['num'], "Ticket Reopened", $_POST['sender'], "0", "0");
        add_comment($fields, startConn());
        $ticket = load_tick($_POST['num'], startConn());
        $t_id = $ticket['TNum'];
    }
} else {
    $ticket = load_tick($t_id, startConn());
    $t_id = $ticket['TNum'];
    //echo '<br><br>ELSE'. $ticket['TNum'];
}

$_SESSION['log'] = get_comment($t_id, startConn());

if ($t_id < 10) {
    $val = '0000' . $t_id;
} elseif ($t_id < 100) {
    $val = '000' . $t_id;
} elseif ($t_id < 1000) {
    $val = '000' . $t_id;
} else {
    $val = '0' . $t_id;
}
$ticket['TNum'] = $val;
$t_id = $val;
//echo  "<br> ||2". $_POST['assignment'];
//echo "<br>" . $t_id. " ||1". $_POST['num'];

$horizon_divider = "$rowstart <div class=\"col px-3\"><hr></div>$rowend";
$confirm_reopen = "    <div class=\"modal fade\" id=\"reopenModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
                            <div class=\"modal-dialog\" role=\"document\">
                                <div class=\"modal-content\">
                                    <div class=\"modal-header\">
                                        <h5 class=\"modal-title\" id=\"exampleModalLabel\">Are you sure?</h5>
                                        <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">
                                            <span aria-hidden=\"true\">×</span>
                                        </button>
                                    </div>
                                    <div class='modal-body text-center'><p>Please select \"Confirm\" to Reopen!</p><p class='text-center'></p></div>
                                    <div class=\"modal-footer\">
                                        <form class = \"row\" action=" . $_SERVER['PHP_SELF'] . " method=\"POST\">
                                            <input type='hidden' name='num' value='" . $ticket['TNum'] . "'>
                                            <input type='hidden' name='sender' value='" . $_SESSION['fname'] . "'>
                                            <input type='hidden' name='status' value='" . $ticket['status'] . "'>
                                            <input type='hidden' name='act' value='reopen'>
                                            <input type='hidden' name='comments' value='Ticket closed by Management'>
                                            <div class='col'>
                                                <button class=\"btn btn-secondary\" type=\"button\" data-dismiss=\"modal\">Cancel</button>
                                            </div>
                                            <div class='col'>
                                                <input  type = \"Submit\" value=\"Confirm!!\" class=\"btn btn-outline-success btn-user btn-block font-weight-bold btn mb-2\">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>";
$confirm_close = "    <div class=\"modal fade\" id=\"closeModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
                            <div class=\"modal-dialog\" role=\"document\">
                                <div class=\"modal-content\">
                                    <div class=\"modal-header\">
                                        <h5 class=\"modal-title\" id=\"exampleModalLabel\">Are you sure?</h5>
                                        <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">
                                            <span aria-hidden=\"true\">×</span>
                                        </button>
                                    </div>
                                    <div class='modal-body text-center'><p>Please select \"Confirm\" to close the ticket!</p><p class='text-center'></p></div>
                                    <div class=\"modal-footer\">
                                        <form class = \"row\" action=" . $_SERVER['PHP_SELF'] . " method=\"POST\">
                                            <input type='hidden' name='num' value='" . $ticket['TNum'] . "'>
                                            <input type='hidden' name='sender' value='" . $_SESSION['fname'] . "'>
                                            <input type='hidden' name='status' value='" . $ticket['status'] . "'>
                                            <input type='hidden' name='act' value='close'>
                                            <input type='hidden' name='comments' value='Ticket closed by Management'>
                                            <div class='col'>
                                                <button class=\"btn btn-secondary\" type=\"button\" data-dismiss=\"modal\">Cancel</button>
                                            </div>
                                            <div class='col'>
                                                <input  type = \"Submit\" value=\"Confirm!!\" class=\"btn btn-danger btn-user btn-block font-weight-bold btn mb-2\">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>";

$open_button= "$horizon_divider$rowstartjustifycenter <div class='col-4'>
                        $rowstartjustifycenter
                            <div class='col font-weight-bold mt-2'>                                        
                                                    <button class=\"btn btn-outline-success\" type=\"button\" data-toggle=\"modal\" data-target=\"#reopenModal\">ReOpen This Ticket</button>
                                                       $confirm_reopen 
                            </div></div>  $rowend
                        $rowend";

$close_btn = "$horizon_divider$rowstartjustifycenter <div class='col-4'>
                        $rowstartjustifycenter
                            <div class='col font-weight-bold mt-2'>                                        
                                                    <button class=\"btn btn-outline-danger\" type=\"button\" data-toggle=\"modal\" data-target=\"#closeModal\">Close This Ticket</button>
                                                       $confirm_close 
                            </div></div>  $rowend
                        $rowend";
if($ticket['status'] == 'Closed' ) {
    $status_btn = $open_button;
} else {
    $status_btn = $close_btn;
}

$ticket_info_card =
    "<div class=\"col dataT\">
                        $rowstart<div class='col-md-4 font-weight-bold'> Ticket Number:</div><div class='col-md-4 text-md-left text-center'>" . $ticket['TNum'] . "</div> $rowend
                        $rowstart<div class='col-md-4 font-weight-bold'> Creator:</div><div class='col-md-4 text-md-left text-center'>" . $ticket['creator'] . "</div>$rowend
                        $rowstart<div class='col-md-4 font-weight-bold'> Category:</div><div class='col-md-4 text-md-left text-center'>" . $ticket['cat_title'] . "</div>$rowend
                        $rowstart<div class='col-md-4 font-weight-bold'> Email:</div><div class='col-md-4 text-md-left text-center'>" . substr($ticket['email'], 0, 4) . "*****" . "</div> $rowend
                        $rowstart<div class='col-md-4 font-weight-bold'> Phone:</div><div class='col-md-4 text-md-left text-center'>" . $ticket['phone'] . "</div>$rowend
                        $rowstart<div class='col-md-4 font-weight-bold'> Assignee:</div><div class='col-md-4 text-md-left text-center'>" . $ticket['assignee'] . "</div>$rowend
                        $rowstart<div class='col-md-4 font-weight-bold'> Status:</div><div class='col-md-4 text-md-left text-center'>" . $ticket['status'] . "</div>$rowend
                        $rowstart<div class='col-md-4 font-weight-bold'> Time Since Open:</div><div class='col-md-3 text-md-left text-center'>" . $ticket['total_time_open'] . "</div>$rowend
                        $status_btn
                    </div>";

$team_input = "
                            <div class='col'>
                            $rowstartjustifycenter
                                <form class='col' action=" . $_SERVER['PHP_SELF'] . " method=\"POST\">
                                    <input type='hidden' name='num' value='".$ticket['TNum']. "'>
                                    <input type='hidden' name='sender' value='".$_SESSION['fname']. "'>
                                    <input type='hidden' name='assignment' value='comment'>
                                    $rowstartjustifycenter
                                        <div class='col-4 font-weight-bold  form-group m-1'>
                                            <label class='font-weight-bold m-1'> Staff View Only:</label>    
                                            <input class='form-control-user scale ' type=\"checkbox\" name='viewonly' value='1'>
                                        </div>
                                        <div class='col-4 align-content-center m-1 form-group'>
                                            <label class='font-weight-bold m-1'> Placing Work Order:</label>    
                                            <input id='order' class='form-control-user scale ' type=\"checkbox\" name='workorder' onclick=\"unhide()\" value='1'>
                                        </div>
                                    $rowend                                    
                                    $rowstartjustifycenter
                                         
                                        <div id='add_field' class='col-md-4 font-weight-bold m-1 form-control-user form-group'>
                                            <input  class='form-control form-control-user' type=\"text\" name='poc' placeholder='Enter Point of Contact'>
                                        </div>
                                        <div id='add_field1' class='col-md-4 font-weight-bold m-1 form-control-user form-group'>                                        
                                            <input  class='form-control form-control-user' type=\"text\" name='cost' placeholder='Enter Cost for service item'>
                                        </div>
                                    $rowend
                                    $rowstartjustifycenter 
                                        <div id='add_field2' class='col-md-4 font-weight-bold m-1 form-control-user form-group'> 
                                            <input  class='form-control form-control-user' type=\"text\" name='contact' placeholder='Contact Phone or Email'>
                                        </div>
                                        <div class='col-md-4 text-md-left text-center form-group m-1'>
                                            
                                        </div>
                                    $rowend
                                    $horizon_divider
                                    $rowstartjustifycenter
                                                    <div class=\"col-lg col-sm\">
                                                                <div>
                                                                    <label class='font-weight-bold'> Enter Comment/Task:</label><br>
                                                                </div>
                                                                <div>
                                                                    <textarea   name=\"comments\" placeholder=\"Enter text here...\" style=\"height: 100px;\"
                                                                      class=\"form-control form-control-user mb-2\" maxlength=\"2000\" cols=\"40\" rows=\"5\"></textarea>
                                                                </div>
                                                    </div>
                                                    $rowend $rowstart
                                                    <div class=\"col-lg-3 my-2\">
                                                        <input  type = \"submit\" value=\"Send Message\" class=\"btn btn-primary btn-user btn-block mb-1\">
                                                    </div> $rowend
                                    
                                </form>
                                $rowend
                            </div>  
                                           
                                                 
                                                  
                                                 
                                     <script> 
                                     function unhide() {
                                      var checkBox = document.getElementById(\"order\");
                                      // Get the output text
                                      var text = document.getElementById(\"add_field\");
                                      var text1 = document.getElementById(\"add_field1\");
                                      var text2 = document.getElementById(\"add_field2\");
                                      // If the checkbox is checked, display the output text
                                      if (checkBox.checked == true){
                                        text.style.display = \"block\";
                                        text1.style.display = \"block\";
                                        text2.style.display = \"block\";
                                        
                                      } else {
                                        text.style.display = \"none\";
                                        text1.style.display = \"none\";
                                        text2.style.display = \"none\";
                                        
                                      }
                                    } unhide()
                                    </script>
                                                                 
                                ";