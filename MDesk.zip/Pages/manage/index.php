<?php

require 'Pages/redirect.php';
header("Location: /");
