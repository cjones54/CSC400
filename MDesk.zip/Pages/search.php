<?php
$page_id = "search";
include_once "Includes/includes.php";
include_once "Includes/DataLayer/reportingtypes.php";
//    $graph_data = standard_ticket_breakdown($conn);
//    $labels = json_encode($graph_data[0]);
//    $data1 = json_encode($graph_data[1]);
    //$labels = json_encode("[ '".$graph_data[0][0]."', '".$graph_data[0][1]."','".$graph_data[0][2]."', '".$graph_data[0][3]."'");
    //$data1 = json_encode("[ '".$graph_data[1][0]."', '".$graph_data[1][1]."','".$graph_data[1][2]."', '".$graph_data[1][3]."'");
validateLogin($_SESSION['Logged In']);
echo pageScripts("default");
echo $header;

?>
<script src="/vendor/chart.js/Chart.min.js"></script>
<body id="page-top"  >

<!-- Page Wrapper -->
<div id="wrapper">

    <?php
    //side navbar defined in /php/mainHeader
    echo $navbar;
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == true){
            echo $topbar;
        }

        ?>
        <!-- Begin Page Content -->
        <div class="container-fluid ">

                <?php
                    echo $contentHeader; //edit in php/mainHeader.php
;
//Ticket Reporting
                //Form fields to calculate tickets in a variety of
//                    echo $rowstart;
//                    echo $reportTable;
//                    echo pageScripts("table");
//                    echo $rowend;
//line graph test (not for final)

                    echo $rowstart;

                    echo $bargraph;

                    echo $rowend;
                ?>


        </div>

    </div>
    <!-- /.container-fluid -->

</div><!-- End of Main Content - wrapper -->

<?php
    echo $footer

?>

<!-- End of Content Wrapper -->

<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>



<?php
echo $logout;
echo $bargraphscript;
echo pageScripts("default");

?>



</body>

</html>
