<?php
$page_id = "ticketcheck";
$_SERVER['PHP_SELF'] = "/ticketcheckup";
$errorTicketnumber = "";
$comment_log = "";
$ticketnum = "";
$confirmation = false;
$creatortype = ""; // auto trigger dependent on login
$fname = "";
$fname = "";
$userEmail = "";
$phone = "";
$phone1 = "";
$phone2 = "";
$phone3 = "";
$issue = ""; //issue set from list
$address ="";
$status = "";
$assignee = "";
$comment = ""; //team side & ticket checkup
$total_cost = ""; //team side compiled from ticket
$issue_type = 0;
$issueArray = array(
    "0" => "Please select...",
);



include_once "Includes/includes.php";
include_once "Includes/Parts/checkticketproc.php";

echo $header;
?>


<body id="page-top">
<!-- Page Wrapper -->
<div id="wrapper">
    <?php //side navbar defined in /php/mainHeader
    echo $navbar;
    ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == True){
            echo $topbar;
        }
        ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
            <?php
            echo $contentHeader; //edit in php/mainHeader.php
            ?>
            <div class="" >
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-1">
                        <!-- Nested Row within Card Body -->
                        <div class="row justify-content-center">
                            <div class="col-xl-10 col-lg-10 col-md-10">
                                <?php if(!isset($_SESSION['confirmation']))
                                    {  echo  "<div class=\"p-3\">" . $rowstartjustifycenter?>
                                        <div class="text-left">
                                            <h1 class="h4 text-gray-900 ">Please fill out the fields below:</h1>
                                        </div>

                                        <?php echo $rowend . $rowstartjustifycenter. "<div class=\"col-3 d-lg-block\"><hr></div>". $rowend . $rowstartjustifycenter ?>

                                        <form class="col" action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
                                            <?php echo $rowstartjustify ?>

                                            <div class='col align-text-bottom justify-content-start'>
                                                <div class="row">
                                                <label>Email</label>
                                                </div>
                                                <div class="row form-group">
                                                    <input type="email" name="creatorEmail" value="<?php echo $userEmail ?>" class="form-control form-control-user" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                                                    <?php
                                                    echo $emailError;
                                                    ?>
                                                </div>
                                            </div>
                                            <?php echo $rowend . $rowstartjustify ?>

                                            <div class='col align-text-bottom justify-content-start d-lg-block'>
                                                <div class="row">
                                                    <label>Ticket Number</label>
                                                </div>
                                                <div class="row form-group">
                                                    <input type="text" pattern="^\d{6}$" name="ticketnumber" class="form-control form-control-user"  value ="<?php echo $ticketnum ?>"  placeholder="######" maxlength="6" required>
                                                </div>
                                                <?php
                                                echo $errorTicketnumber;
                                                ?>

                                            </div>
                                            <?php echo $rowend?>
                                                    <?php
                                                    if(!isset($_SESSION['real_user']) && !$_SESSION['real_user']) {
                                                        echo $rowstart. "<div class=\"col px-2\"><hr></div>". $rowend . $rowstartjustifycenter;
                                                        echo $captcha_form . $captcha_script. $statusMsg;
                                                        echo $rowend. $rowstart. "<div class=\"col px-3\"><hr></div>". $rowend;
                                                    }
                                            echo $rowstartjustifycenter;  ?>

                                            <div class="col-lg-3 my-2">
                                                <input type = "submit" name="submit" value ="Submit" class="btn btn-primary btn-user btn-block mb-1">
                                            </div>
                                            <?php
                                            echo $rowend;
                                            ?>
                                        </form>

                                        <?php
                                        echo $rowend. $rowstartjustifycenter ."<form class = \"col\" action=\"/\">". $rowstartjustifycenter ;
                                        ?>
                                                    <div class="col-lg-3 my-2">
                                                        <input  type = "submit" value="Go to Main Page" class="btn btn-primary btn-user btn-block mb-1">
                                                    </div>
                                        <?php
                                        echo $rowend." </form>". $rowend . "</div>";

                                    }
                                    else {

                                        if ($ticket['status'] == 'Open'){

                                            $confirm_close = "    <div class=\"modal fade\" id=\"closeModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
                                                                    <div class=\"modal-dialog\" role=\"document\">
                                                                        <div class=\"modal-content\">
                                                                            <div class=\"modal-header\">
                                                                                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Are you sure?</h5>
                                                                                <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">
                                                                                    <span aria-hidden=\"true\">×</span>
                                                                                </button>
                                                                            </div>
                                                                            <div class='modal-body text-center'><p>Please select \"Confirm\" to close the ticket!</p><p class='text-center'>(This cannot be undone!!)</p></div>
                                                                            <div class=\"modal-footer\">
                                                                               <form class = \"row\" action=" . $_SERVER['PHP_SELF'] . " method=\"POST\">                                                                                  
                                                                                   <input type='hidden' name='num' value='".$ticket['TNum']. "'>
                                                                                       <input type='hidden' name='sender' value='".$ticket['creator']. "'>
                                                                                       <input type='hidden' name='close' value='true'>
                                                                                       <input type='hidden' name='opened' value='".$ticket['opened']. "'>
                                                                                       <input type='hidden' name='comments' value='Ticket Closed By Customer'>
                                                                                       <div class='col'>
                                                                                       <button class=\"btn btn-secondary\" type=\"button\" data-dismiss=\"modal\">Cancel</button>
                                                                                       </div>
                                                                                       <div class='col'>                                                                                   
                                                                                        <input  type = \"Submit\" value=\"Confirm!!\" class=\"btn btn-danger btn-user btn-block font-weight-bold btn mb-2\">                                                            
                                                                                    </div>
                                                                                </form>                                                                            
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>";
                                        $comment_form =
                                            " <form class=\"col\" action=" . $_SERVER['PHP_SELF'] . " method=\"POST\">
                                                 <input type='hidden' name='num' value='".$ticket['TNum']. "'>
                                                 <input type='hidden' name='sender' value='". $ticket['creator'] . "'>
                                                 <input type='hidden' name='close' value='false'>
                                                    <div class=\"col-lg col-sm\">
                                                                <div>
                                                                    <label class='font-weight-bold'> Need to add something:</label><br>
                                                                </div>
                                                                <div>
                                                                    <textarea name=\"comments\" placeholder=\"Enter text here...\" style=\"height: 100px;\"
                                                                      class=\"form-control form-control-user mb-2\" maxlength=\"2000\" cols=\"40\" rows=\"5\"></textarea>
                                                                </div>
                                                    </div>
                                                    <div class=\"col-lg-3 my-2\">
                                                        <input  type = \"submit\" value=\"Send Message\" class=\"btn btn-primary btn-user btn-block mb-1\">
                                                    </div> 
                                                 </form>
                                            ";
                                            $close_btn = "$rowstart <div class=\"col-sm px-3\"><hr></div>$rowend $rowstartjustifycenter
                                                                <div class='col-7 font-weight-bold mt-2'>                                        
                                                                    <button class=\"btn btn-outline-danger\" type=\"button\" data-toggle=\"modal\" data-target=\"#closeModal\">I'm no longer have this issue!! (Close this ticket)</button>
                                                                   $confirm_close </div>$rowend";


                                        } else {

                                            $comment_form = "
                                            <div class=\"col-lg col-sm font-weight-bold\"> This ticket has been closed. If this issue or request has reoccurred, please submit a new ticket <a class='text-primary' href='/ticketsubmit'>here</a> include this ticket number as reference. Thank you!</div>";
                                            $confirm_close ="";
                                            $close_btn = "";

                                        }

                                        $confirm =
                                            "<div class='px-2 mt-1'>
                                                        <div class=\"row justify-content\">                                                            
                                                            <form class = \"col user\" action=\"/ticketcheckup\">                                                            
                                                                    <input  type = \"Submit\" value=\"Need to Check on Another another Ticket?\" class=\"btn btn-primary btn-user btn-block font-weight-bold mb-2\">                                                            
                                                            </form>
                                                            <form class = \"col user\" action=\"/\">
                                                                <input  type = \"submit\" value=\"Go to Main Page\" class=\"btn btn-primary btn-user btn-block font-weight-bold mb-2\">                                                                                                                   
                                                            </form>
                                                        </div>
                                                $rowstart
                                                    <div class=\"col dataT\">
                                                            $rowstart<div class='col-md-4 font-weight-bold'> Ticket Number:</div><div class='col-md-3 text-md-left text-center'>" . $ticket['TNum'] . "</div> $rowend
                                                            $rowstart<div class='col-md-4 font-weight-bold'> Creator:</div><div class='col-md-3 text-md-left text-center'>" . $ticket['creator'] . "</div>$rowend
                                                            $rowstart<div class='col-md-4 font-weight-bold'> Category:</div><div class='col-md-3 text-md-left text-center'>" . $ticket['cat_title'] . "</div>$rowend
                                                            $rowstart<div class='col-md-4 font-weight-bold'> Email:</div><div class='col-md-3 text-md-left text-center'>" . substr($ticket['email'], 0, 4)."*****" . "</div> $rowend
                                                            $rowstart<div class='col-md-4 font-weight-bold'> Phone:</div><div class='col-md-3 text-md-left text-center'>" . $ticket['phone'] . "</div>$rowend
                                                            $rowstart<div class='col-md-4 font-weight-bold'> Status:</div><div class='col-md-3 text-md-left text-center'>" . $ticket['status'] . "</div>$rowend
                                                            $close_btn
                                                            </div>  
                                                            $rowstart <div class=\"col-sm px-3\"><hr></div>$rowend                                                
                                                                <div class='col-lg m-2 table-responsive'>
                                                                       " . $_SESSION['log'] ."
                                                                </div> ;                                    
                                             $rowend  
                                             $rowstart <div class=\"col px-3\"><hr></div>$rowend 
                                             $rowstart
                                             
                                             $comment_form 
                                                 
                                             $rowend         
                                             
                                                  </div>                                  
                                            ";

                                        echo $confirm ;


                                    }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </div><!-- End of Main Content - wrapper -->
</div><!-- End of Content Wrapper -->
<?php
echo $footer
?>
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<?php
echo $logout;
echo pageScripts("default");
echo pageScripts('log');
?>

</body>

</html>

