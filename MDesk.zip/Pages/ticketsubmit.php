<?php
$page_id = "ticketsub";
$topbar = "";
$errorAddr ="";
$_SERVER['PHP_SELF'] = "/ticketsubmit";
$_POST['confirmation'] = false;
$confirmation = false;
$creatortype = ""; // auto trigger dependent on login
$fname = "";
$userEmail = "";
$phonesvc = "";
$phone = "";

$phone1 = "";
$phone2 = "";
$phone3 = "";
$issue = ""; //issue set from list
$address ="";
$status = "";
$assignee = "";
$description = "";
$comment = ""; //team side & ticket checkup
$total_cost = ""; //team side compiled from ticket
$issue_type = 0;


include_once "Includes/includes.php";
include_once "Includes/Parts/ticketproc.php";
include_once "Includes/Parts/csrf.class.php";


$csrf = new csrf();
// Generate Token Id and Valid
$token_id = $csrf->get_token_id();
//$token_value = $csrf->get_token($token_id);

// Generate Random Form Names
//$form_names = $csrf->form_names(array('user', 'password'), false);





echo $header; //Common HTML Parts
?>


<body id="page-top">
<!-- Page Wrapper -->
<div id="wrapper">
    <?php
        echo $navbar; //side navbar defined in /php/mainHeader
    ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <?php

        if($_SESSION['team_user'] == True){ //Validate if the user is logged in
            echo $topbar;  //Top Nav bar defined in /php/mainHeader
        }
        ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
            <?php
            echo $contentHeader; //edit in php/mainHeader.php
            ?>
            <div class="" >
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-1">
                        <!-- Nested Row within Card Body -->
                        <div class="row justify-content-center">
                            <div class="col-xl-10 col-lg-10 col-md-10">
                               <?php if(!isset($_SESSION['confirmation']))
                                                {  echo  "<div class=\"p-3\">" . $rowstartjustify?>
                                                            <div class="text-left">
                                                            <h1 class="h4 text-gray-900 ">Please fill out the fields below:</h1>
                                                            </div>
                                                <?php echo $rowend . $rowstart. "<div class=\"col d-lg-block\"><hr></div>". $rowend . $rowstartjustify ?>

                                                <form class="col" action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
                                                    <?php echo $rowstartjustify ?>

                                                    <div class='col-md col-sm col- align-text-bottom justify-content-start mx-1 p-1'>
                                                        <label>Email</label>
                                                        <div class="form-group">
                                                            <input type="email" name="creatorEmail" value="<?php echo $userEmail ?>" class="form-control form-control-user" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                                                            <?php
                                                            echo $emailError;
                                                            ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>First Name:</label>
                                                            <input type="text" name="firstName" id="firstName" value="<?php echo $fname ?>" class="form-control form-control-user" placeholder="Your First Name" required>
                                                            <?php
                                                            echo $errorFname;
                                                            ?>
                                                        </div>
                                                        <div>
                                                            <label>Last Name:</label>
                                                            <input type="text" name="lastName" id="lastName" value="<?php echo $lname ?>" class="form-control form-control-user" placeholder="Your Last Name" required>
                                                            <?php
                                                            echo $errorLname;
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class='col-md col-sm col- align-text-bottom justify-content-start ml-1 p-1'>
                                                        <div class="row align-content-start">
                                                            <label>Address:</label>
                                                        </div>
                                                        <div class="row align-content-start">
                                                            <input type="text" name="address" id="address" class="form-control form-control-user" value ="<?php echo $address ?>" placeholder="Street Address" required>
                                                            <?php
                                                            echo $errorAddr;
                                                            ?>
                                                        </div>
                                                        <div class="row mt-3">
                                                            <label>Contact Phone #:</label>
                                                        </div>
                                                        <div class="row d-inline-flex justify-content-start mb-3">
                                                                <div class="col px-1 "><input type="tel" pattern="^\d{3}$" name="phone1" class="form-control form-control-user"   value ="<?php echo $phone1 ?>"  placeholder="(xxx)" maxlength="3" required></div>
                                                                <div class="col px-1 "><input type="tel" pattern="^\d{3}$" name="phone2" class="form-control form-control-user"  value ="<?php echo $phone2 ?>"  placeholder="xxx" maxlength="3" required></div>
                                                                <div class="col-5 px-1 "><input type="tel" pattern="^\d{4}$" name="phone3" class="form-control form-control-user"  value ="<?php echo $phone3 ?>"  placeholder="xxxx" maxlength="4" required></div>
                                                        </div>
                                                        <?php
                                                            echo $errorPhone;
                                                        ?>
                                                        <div class="row align-content-start">
                                                            <label>Issue Type</label>
                                                            <select name="issueArea" class="form-control form-control-user" >
                                                                <?php
                                                                foreach ($issueArray as $key => $value) {
                                                                    if ($issue_type == $key) {
                                                                        echo "<option value=\"$key\" selected>$value</option>";
                                                                    } else {
                                                                        echo "<option value=\"$key\">$value</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <?php echo $rowend. $rowstart. "<div class=\"col\"><hr></div>". $rowend . $rowstartjustifycenter;  ?>
                                                    <div class="col-lg-10 col-sm-4 d-lg-block">
                                                            <div>
                                                                <label> Please explain to the best level of details possible:</label><br>
                                                            </div>
                                                            <div>
                                                                <textarea name="description" placeholder="Enter text here..." style="height: 100px;"
                                                                  class="form-control form-control-user mb-2" maxlength="2000" cols="40" rows="5"><?php echo $description ?></textarea>
                                                            </div> <?php echo $errorDesc; ?>
                                                    </div>
                                                    <?php echo $rowend;
                                                                    if(!isset($_SESSION['real_user']) && !$_SESSION['real_user']) {
                                                                        echo "<hr>";
                                                                        echo $captcha_script;
                                                                        echo $captcha_form;
                                                                        echo $statusMsg;
                                                                    }

//                                                                if(!isset($_SESSION['real_user']) && !$_SESSION['real_user']) {
//                                                                    echo $rowstart. "<div class=\"col px-2\"><hr></div>". $rowend . $rowstartjustifycenter;
//                                                                    echo $captcha_form . $captcha_script. $statusMsg;
//                                                                    echo $rowend. $rowstart. "<div class=\"col px-3\"><hr></div>". $rowend;
//                                                                }
                                                    echo $rowstartjustifycenter;  ?>
                                                    <hr>
                                                    <div class="col mx-5 my-2">
                                                        <input type = "submit" name="submit" value ="Submit" class="btn btn-primary btn-user btn-block mb-1">
                                                    </div>
                                                    <?php
                                                    echo $rowend;
                                                        ?>
                                                </form>

                                                <?php
                                                echo $rowend. $rowstartjustifycenter ."<form class = \"form-group\" action=\"/\">".$rowend. $rowstartjustifycenter;
                                                ?>

                                                        <div class="col mx-5 my-2">
                                                        <input  type = "submit" value="Go to Main Page" class="btn btn-primary btn-user btn-block mb-1">
                                                        </div>
                                                <?php
                                                    echo $rowend." </form>". $rowend . "</div>";

                                            } else {

                                                //echo $rowstart;
                                                $confirm =
                                                       "<div>
                                                        $rowstart 
                                                        <div class=\"d-block text-center m-3\">
                                                            <p>Your ticket number is:  " . $ticket . " </p><br>
                                                            <p>Thank you for your submission</p>
                                                            <p>
                                                            Anyone who will contact you regarding this request will not ask for any personal information. 
                                                            Simply keep the ticket number and we will reach out via phone from xxx.xxx.xxxx or email if further 
                                                            information or scheduling is needed.
                                                            </p>
                                                        </div>                                      
                                                        $rowend  
                                                        $rowstartjustifycenter 
                                                       <form class = \"col-2 user\" action=\"/\">
                                                            <div class=\"row justify-content-center d-block\">
                                                                <input  type = \"submit\" value=\"Go Back\" class=\"btn btn-primary btn-user btn-block mb-2 p-2\">
                                                            </div>                                                                                                              
                                                       </form>
                                                       $rowend 
                                                       $rowstartjustifycenter
                                                       <form class = \" col-2 user\" action=\"/ticketsubmit\">
                                                            <div class=\"row justify-content-center d-block\">
                                                                <input  type = \"submit\" value=\"Need to submit another?\" class=\"btn btn-primary btn-user btn-block mb-2\">
                                                            </div>
                                                       </form>
                                                       $rowend                                                      
                                                       </div>
                                                        ";
                                               echo $confirm;


                                 }?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php
                echo $footer
                ?>
            </div>
        </div><!-- /.container-fluid -->

    </div><!-- End of Main Content - wrapper -->

</div><!-- End of Content Wrapper -->


<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<?php
echo $logout;
echo pageScripts("default");
?>

</body>

</html>

