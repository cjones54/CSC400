<?php
echo "Message Page";

echo pageScripts("default");
