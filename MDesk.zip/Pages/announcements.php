<?php
$page_id = "add_news";
$_SERVER['PHP_SELF'] = "/announcements";
$content = "";
$title = "";
$loadfile = '';
$fileError= "";
$errorContent = "";
$TitleError = "";

include_once "Includes/includes.php";
$creator = $_SESSION['name'];
validateLogin($_SESSION['Logged In']);
include_once "Includes/Parts/newsproc.php";
echo pageScripts("default");
echo $header;
?>
<body id="page-top">
<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    //side navbar defined in /php/mainHeader
    echo $navbar;
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <?php
        //Top Nav bar defined in /php/mainHeader
        if($_SESSION['team_user'] == True){
            echo $topbar;
        }
        ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
            <?php
            echo $contentHeader; //edit in php/mainHeader.php
            ?>
                <div class="col-xl-10 col-lg-10 col-md-8">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row justify-content-center">
                                <div class="col-xl-10 col-lg-10 col-md-8">
                                        <div class="p-1">
                                            <div class="text-left">
                                                <br>
                                                <h1 class="h4 text-gray-900 mb-4">Please fill out the fields below (Submissions immediately posted):</h1>
                                            </div>
                                            <?php if(!$confirmation){
                                            ?>
                                            <div class="row justify-content-center">
                                                <form class=" " action="<?php echo $_SERVER['PHP_SELF']?>" enctype="multipart/form-data" method="post"">
                                                    <div class="row justify-content-between">
                                                        <div class='col-lg-5 d-none d-lg-block'>

                                                            <div class="form-group ">
                                                                <input type="text" name="title" value="<?php echo $title ?>" class="form-control form-control-user " id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Title">
                                                            </div>
                                                            <?php
                                                            echo $TitleError;
                                                            ?>
                                                            <div class="form-group">
                                                                <input type="text" name="creator" id="firstName" value="<?php echo $creator ?>" class="form-control form-control-user" placeholder="Creator" required>
                                                            </div>
                                                            <div class="form-group">

                                                                <input type="file" class="btn-sm btn-secondary" name="file" id='file' >
                                                                <label>Choose Image/Banner File (.jpg/.png)</label>
                                                            </div>
                                                            <?php
                                                            echo $fileError;
                                                            ?>
                                                        </div>
                                                            <div class='col-lg-5 d-none d-lg-block '>

                                                                <label style="align: left"> Content:</label><br>
                                                                <textarea  name="content"
                                                                          placeholder="Enter text here..." style="height: 100px;" class="form-control form-control-user" maxlength="100" cols="40" rows="5"><?php echo $content ?></textarea>

                                                                <?php
                                                                echo $errorContent; ?>

                                                            </div>
                                                    </div>

                                                    <?php
                                                    echo $rowstartjustify;
                                                    ?>
                                                        <hr>
                                                        <div class="col-lg-8 d-lg-block p-2">
                                                                    <?php
                                                                    $_SESSION['real_user'] = true;
                                                                    echo $captcha_script;
                                                                    echo $captcha_form;
                                                                    echo $statusMsg;
                                                                    ?>
                                                        </div>
                                                    <?php echo $rowend;
                                                    ?>
                                                    <input type = "submit" name = 'submit' value ="Post" class="btn btn-primary btn-user btn-block">
                                                </form>

                                            </div>
                                                <?php
                                                echo $rowstartjustify;
                                                ?>

                                                <form class = "user" action="/TeamDashboard">
                                                    <input  type = "submit" value="Go Back" class="btn btn-primary btn-user btn-block">
                                                </form>
                                                <?php
                                                echo $rowend;
                                                 } else {
                                                    foreach ($id_variables_Check as $item) {
                                                        echo $item . "<br>";
                                                    }
                                                echo $id_variables_Check;
                                                echo "<div \"col-xl-2\"><p>Posted</p><br>
                                                  <p>Thank you for your submission</p></div>                                          

                                            <form class = \"user\" action=\"/TeamDashboard\">
                                                <input  type = \"submit\" value=\"Go Back\" class=\"btn btn-primary btn-user btn-block\">
                                            </form>";
                                            }?>
                                        </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
    </div><!-- End of Main Content - wrapper -->
</div><!-- End of Content Wrapper -->
<?php
echo $footer
?>





<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<?php
echo $logout;
echo pageScripts("default");
?>

</body>

</html>

