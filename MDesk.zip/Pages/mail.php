<?php
//$STATIC_SMTP = '';
//$STATIC_USER = '';
//$STATIC_PASS = '';
//
//require 'phpmailer/src/Exception.php';
//require 'phpmailer/src/PHPMailer.php';
//require 'phpmailer/src/SMTP.php';
//
//
//use PHPMailer\PHPMailer\SMTP;
//use PHPMailer\PHPMailer\PHPMailer;
//use PHPMailer\PHPMailer\Exception;

//function mailer($host, $use, $pass, $destination, $sub, $msg)
//{
//// Instantiation and passing `true` enables exceptions
//    $mail = new PHPMailer(true);
//    echo 'Initiated';
//    try {
//        //Server settings
//        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
//        $mail->isSMTP();                                            // Send using SMTP
//        $mail->Host = $host;                    // Set the SMTP server to send through
//        $mail->SMTPAuth = true;                                   // Enable SMTP authentication
//        $mail->Username = $use;                     // SMTP username
//        $mail->Password = $pass;                               // SMTP password
//        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
//        $mail->Port = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
//        echo 'trying';
//        //Recipients
//        $mail->setFrom('christianj34@gmail.com', 'MDesk no-reply');
//        $mail->addAddress($destination, 'CJ');     // Add a recipient
//        //$mail->addAddress('c.jones54@outlook.com');               // Name is optional
//        $mail->addReplyTo('christianj34@gmail.com', 'MDesk');
//        //$mail->addCC('cc@example.com');
//        //$mail->addBCC('bcc@example.com');
//
//        // Attachments
//        //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
//
//        // Content
//        $mail->isHTML(true);                                  // Set email format to HTML
//        $mail->Subject = $sub;
//        $mail->Body = $msg;
//        $mail->AltBody = $msg;
//
//        $mail->send();
//        echo 'sent!';
//        return 'Message has been sent';
//
//    } catch (Exception $e) {
//        echo 'fail: ' .  $mail->ErrorInfo;
//        return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
//    }
//}
//$recipient = "c.jones54@outlook.com";
//$subject = "MDesk Maintenaince Ticket Request";
//$message = "<body>
//                                <p>This is an automatic message:</p>
//                                <p>Your ticket number is:  " . $ticket . ", please retain for your records.</p><br>
//                                <p>Thank you for your submission</p>
//                                <p>
//                                Anyone who will contact you regarding this request will not ask for any personal information.
//                                Simply keep the ticket number and we will reach out via phone from xxx.xxx.xxxx or email if further
//                                information or scheduling is needed.
//                                </p>
//                            </body>   ";
//
//$result = mailer($STATIC_SMTP, $STATIC_USER, $STATIC_PASS, $recipient, $subject, $message);
//echo $result;