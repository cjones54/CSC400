<?php
//
include_once "DataLayer/SQLinterface.php";
include "Parts/scripts.php";
include_once "Parts/session.php";
include_once "Parts/containers.php";

include_once 'DataLayer/top_nav_proc.php';

include_once "Parts/mainHeader.php";
include_once "Parts/Cards.php";
include_once "Parts/UpdatesTable.php";
include_once "Parts/Graphs.php";


include_once "DataLayer/functions.php"; //logIPAddr Function
include_once "DataLayer/routinefunction.php";


logIpAddr($_SERVER['PHP_SELF'], startConn());


