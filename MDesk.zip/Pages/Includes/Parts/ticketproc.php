<?php
include_once "captcha.php";
require_once  'Includes/DataLayer/SQLinterface.php';
$email_conf = get_email_config();
if((!empty($email_conf[0])) &&(!empty($email_conf[1])) && (!empty($email_conf[1]))){
    $STATIC_SMTP = $email_conf[0];
    $STATIC_USER = $email_conf[1];
    $STATIC_PASS = $email_conf[2];

}
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';


///////////////////////////////
$id_variables_Check = "";
$emailError = "";
$errorFname = "";
$errorLname = "";
$errorPhone = "";
$emailAddr = "";
$errorDesc = "";
$issueArray = array(
    "0" => "Please select...",);

function get_categories($connect, $currentArray){

    if ($connect->connect_error)
    {
        die("Connection failed1: " . $connect->connect_error);

    } else {


        $sql = "SELECT * FROM MDesk.T_Category ORDER BY Category_ID DESC;";
        $res = mysqli_query($connect, $sql);
        while ($row = mysqli_fetch_assoc($res)) {
            $currentArray[$row['Category_ID']] = $row['cat_title'];
        }
        //$result;
        $connect->close();
        return $currentArray;


    }
}
function mailer($host, $use, $pass, $destination, $sub, $msg)
{
// Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);
    //echo 'Initiated';
    try {
        //Server settings
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host = $host;                    // Set the SMTP server to send through
        $mail->SMTPAuth = true;                                   // Enable SMTP authentication
        $mail->Username = $use;                     // SMTP username
        $mail->Password = $pass;                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
        //echo 'trying';
        //Recipients
        $mail->setFrom($use, 'MDesk no-reply');
        $mail->addAddress($destination, 'MDesk');     // Add a recipient

        $mail->addReplyTo('christianj34@gmail.com', 'MDesk');


        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = $sub;
        $mail->Body = $msg;
        $mail->AltBody = $msg;

        $mail->send();
        //echo 'sent!';
        return; //'Message has been sent';

    } catch (Exception $e) {
        //echo 'fail: ' .  $mail->ErrorInfo;
        return ;
        //"Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}



$issueArray = get_categories(startConn(), $issueArray);
function check_resubmit($num, $sender, $conn)
{
    $sql = "SELECT * FROM MDesk.work_tickets ORDER BY TNum DESC LIMIT 1 ;";
    if (!$conn->query($sql)) {

        return true;
        //die("Connection failed1: " . $conn->connect_error);
    } else {
//        echo "<br>Checking";
        $res = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($res);

//        echo "<br>" . $row['sender'];
//        echo "<br>" . $row['comment'];
        if ($row['TNum'] == $num) {
            //echo "<br> Repeated Comment";
            return true;

        }else {
            //echo "<br> new Comment";
            return false;
        }
    }
}
function team_address($conn){
    $sql = "SELECT primary_key FROM MDesk.users;";
    $return = array();
    if (!$conn->query($sql)) {
        return true;
        //die("Connection failed1: " . $conn->connect_error);
    } else {
        $res = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($res)) {
            array_push($return,$row['primary_key']);
        }
        return $return;
    }
}

function addtick($fields, $connect)
{

    if ($connect->connect_error)
    {
        die("Connection failed1: " . $connect->connect_error);

    } else
    {

        $name = $fields[0] . " " . $fields[1];
        $sql = "insert into MDesk.work_tickets (creator, category, email, phone, address, assignee, status, description, opened) values ( '$name', '$fields[2]', '$fields[3]', '$fields[4]', '$fields[5]', 'unassigned', 'open', '$fields[6]', CURRENT_TIMESTAMP());";

        if(!$connect->query($sql))
        {
            die("Connection failed2: " . $connect->connect_error);
        }
        else
        {

            $sql = "SELECT TNum FROM MDesk.work_tickets ORDER BY TNum DESC LIMIT 1;";
            $res = mysqli_query($connect, $sql);

            $result = mysqli_fetch_assoc($res);
            $num =$result['TNum'];
            $sql = "insert into MDesk.ticket_logs (ticket_ref, comment, sender, action_cost, team_only, datetime) values ('$num', 'Ticket Opened', 'SYSTEM', '0', '0', CURRENT_TIMESTAMP());";
            $connect->query($sql);
            $connect->close();
            return $result['TNum'];
//            if(isset($_POST['sent'])){
//                $check = check_resubmit($_POST['sent'], $connect);
//                if ($check) {
//                        //echo "Repeat";
//                        $connect->close();
//                        return $_POST['sent'];
//                    } else {
//
//                            $dest = team_address($connect);
//                            foreach ($dest as $item) {
//                                //echo 'unassigned';
//
//                                $sql1 = "INSERT INTO MDesk.alerts (recipient_id, alert_msg, unread, date_time) VALUES ('$item', 'Ticket Opened', 1, CURRENT_TIMESTAMP());";
//                                $connect->query($sql1);
//                                //echo $item;
//                            }
//
//
//
//                        if (!$connect->query($sql)) {
//                            echo '<br>Connection failure';
//
//                            return $_POST['sent'];
//                        } else {
//                            //echo '<br>Success';
//                            $connect->close();
//                            return $_POST['sent'];
//                        }
//
//                }
//            }

        }
    }
}




//Ticket Submission Processing
if ($page_id === "ticketsub") {
    $isProcessingForm = false;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $isProcessingForm = true;
        if ($isProcessingForm) {
            // Assign Array Values to local variables
            $userEmail = $_POST['creatorEmail'];
            $fname = $_POST['firstName'];
            $lname = $_POST['lastName'];
            $phone1 = $_POST['phone1'];
            $phone2 = $_POST['phone2'];
            $phone3 = $_POST['phone3'];
            $issue_type =  $_POST['issueArea'];
            $address = $_POST['address'];
            $assignee =  'unassigned';
            $status = 'open';
            $description = $_POST['description'];
            $phone .= $phone1;
            $phone .= $phone2;
            $phone .= $phone3;
            $confirmation = $_POST['confirmation'];

            $id_variables_Check = [$fname, $lname, $issue_type, $userEmail, $phone, $address, $description];



        }
        if (empty($userEmail) || empty($fname) || empty($lname) || empty($phone) || empty($address) || empty($description))
        {
            // Validate fields
            if (empty($userEmail)) {
                $emailError = "<div class='text-black-50'> Please Enter Email!!</div>";
            }if (empty($fname)) {
                $errorFname = "<div class='text-black-50'>Enter First Name!!</div>";
            }if (empty($lname)) {
                $errorLname = "<div class='text-black-50'> Please Last Name!!</div>";
            }if (empty($phone)) {
                $errorPhone = "<div class='text-black-50'>Enter Phone Number!!</div>";
            }if (empty($address)) {
                $errorAddr = "<div class='text-black-50'> Please Enter an address of service needed!!</div>";
            }if (empty($description)) {
                $errorDesc = "<div class='text-black-50'>Enter Description</div>";
            }
            //header("Location: /ticketsubmit");

        }
        elseif($_SESSION['real_user'])
        {

            //Code for Ticket submission into SQL
            //result page for ticket displays with button going back
            $id_variables_Check = [$fname, $lname, $issue_type, $userEmail, $phone, $address, $description];
            if (!isset($_SESSION['confirmation'])) {

                $result = addtick($id_variables_Check, startConn());
                $_SESSION['confirmation'] = true;
                $_SESSION['counter'] = 1;


                if ($result < 10){
                    $ticket = '0000' . $result;

                } elseif ($result < 100){
                    $ticket = '000' . $result;
                } elseif ($result < 1000){
                    $ticket = '000' . $result;
                } else {
                    $ticket = '0' . $result;
                }
                if((!empty($email_conf[0])) && (!empty($email_conf[1])) && (!empty($email_conf[2]))) {
                    $recipient = $userEmail;
                    $subject = "MDesk Maintenaince Ticket Request";
                    $message = "<body>
                                            <p>This is an automatic message:</p>
                                            <p>Your ticket number is:  " . $ticket . ", please retain for your records.</p><br>
                                            <p>Thank you for your submission</p>
                                            <p>
                                            Anyone who will contact you regarding this request will not ask for any personal information. 
                                            Simply keep the ticket number and we will reach out via phone from xxx.xxx.xxxx or email if further 
                                            information or scheduling is needed. 
                                            </p>
                                        </body>   ";

                    $mail_status = mailer($STATIC_SMTP, $STATIC_USER, $STATIC_PASS, $recipient, $subject, $message);
                    echo $mail_status;
                }
                $_SESSION['result'] = $ticket;
            } elseif ($_SESSION['counter'] < 6){
                $confirmation = true;
                $ticket = $_SESSION['result'];
                $_SESSION['counter'] += 1;

            } else {

                $isProcessingForm =false;
                unset($_SESSION['counter']);
                $_SESSION['real_user'] = false;
                unset($_SESSION['confirmation']);
                unset($_SESSION['result']);
                unset($_POST);
                $id_variables_Check = [];
                header("/ticketsubmit");
//                session_destroy();
//                ob_flush();
            }


        }
    } else{
        unset($_SESSION['confirmation']);
        unset($_SESSION['result']);
        unset($_SESSION['counter']);
        unset($_POST);
    }
}
