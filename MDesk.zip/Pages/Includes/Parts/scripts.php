<?php
function pageScripts ($type)
{




$scripts =
        "<!-- Bootstrap core JavaScript-->
  <script src=\"/vendor/jquery/jquery.min.js\"></script>
  <script src=\"/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>

  <!-- Core plugin JavaScript-->
  <script src=\"/vendor/jquery-easing/jquery.easing.min.js\"></script>

  <!-- Custom scripts for all pages-->
  <script src=\"/js/sb-admin-2.min.js\"></script>

  <!-- Page level plugins -->
  <script src=\"/vendor/datatables/jquery.dataTables.min.js\"></script>
  <script src=\"/vendor/datatables/dataTables.bootstrap4.min.js\"></script>

"

 ;

$slides = "
<script src=\"/js/demo/slide_show.js\"></script>
";


$datatables = "

<!-- Page level custom scripts -->
<script src=\"/js/demo/dashboard.js\"></script>
";
$datatables_logs = "
<script src=\"/js/demo/log_table.js\"></script>";
$linechart = "
<!-- Page level custom scripts -->
 <script src=\"/js/demo/chart-area-demo.js\"></script>

";

$barchart = "
<script src=\"/js/demo/chart-bar-demo.js\" async></script>
";

$piechart = "
<script src=\"/js/demo/chart-pie-demo.js\" async></script>
";

    switch ($type) {
        case "bar":
            return $barchart;
            break;
        case "line":
            return $linechart;
            break;
        case "pie":
            return $piechart;
            break;
        case "table":
            return $datatables;

            break;
        case "log":
            return $datatables_logs;
            break;
        case "slide":
            return $slides;

            break;
        default:
            return $scripts;
            break;
    }
}