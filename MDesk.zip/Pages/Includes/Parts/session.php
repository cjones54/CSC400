<?php




if(!isset($_SESSION['customer'])) {




    $secure = true; // if you only want to receive the cookie over HTTPS
    $httponly = true; // prevent JavaScript access to session cookie
    $samesite = 'strict';
    $maxlifetime = 60000;
    //session_name('MDesk');

    if (PHP_VERSION_ID < 70300) {
        session_set_cookie_params($maxlifetime, '/; samesite=' . $samesite, $_SERVER['HTTP_HOST'], $secure, $httponly);
    } else {
        session_set_cookie_params([
            'lifetime' => $maxlifetime,
            'path' => '/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => $secure,
            'httponly' => $httponly,
            'samesite' => $samesite
        ]);
    }
    session_name('MDesk');
    ob_start();

    session_start();
    $_SESSION['customer'] = true;
}



function setSession ($email, $team_user , $fname, $lname, $failed_logins, $admin_status, $user_id){
    ob_start();
    setcookie('MDesk');
    session_name('MDesk');
    $secure = true; // if you only want to receive the cookie over HTTPS
    $httponly = true; // prevent JavaScript access to session cookie
    $samesite = 'strict';
    $maxlifetime = 60000;
    if(PHP_VERSION_ID < 70300) {
        session_set_cookie_params($maxlifetime, '/; samesite='.$samesite, $_SERVER['HTTP_HOST'], $secure, $httponly);
    } else {
        session_set_cookie_params([
            'lifetime' => $maxlifetime,
            'path' => '/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => $secure,
            'httponly' => $httponly,
            'samesite' => $samesite
        ]);
    }
    session_start();

    $_SESSION['team_user'] = $team_user;

    $_SESSION['email'] = $email;

    $_SESSION['failed_logins'] = $failed_logins;


    $_SESSION['fname'] = $fname;
    $_SESSION['lname'] = $lname;
    $_SESSION['name'] = $fname. " " . $lname;
    $_SESSION['user_id'] = $user_id;
    //teamnav();

    $_SESSION['Logged In'] = true;
    if ($admin_status) {
        $_SESSION['Admin'] = true;
    } else {
        $_SESSION['Admin'] = false;
    }
    header("/TeamDashboard");

}

function endSession(){
    session_destroy();
    ob_flush();
}

$logout =
    "
<!-- Logout Modal-->
    <div class=\"modal fade\" id=\"logoutModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Ready to Leave?</h5>
                <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">
                    <span aria-hidden=\"true\">×</span>
                </button>
            </div>
            <div class=\"modal-body\">Select \"Logout\" Click below if you are ready to end your current session.</div>
            <div class=\"modal-footer\">
                <button class=\"btn btn-secondary\" type=\"button\" data-dismiss=\"modal\">Cancel</button>
                <a class=\"btn btn-primary\" href=\"/logout\">Logout</a>
            </div>
        </div>
    </div>
</div>
";

