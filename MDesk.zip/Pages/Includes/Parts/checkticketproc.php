<?php
include_once "captcha.php";
//include_once 'Pages/Includes/DataLayer/SQLinterface.php';
///////////////////////////////
$id_variables_Check = "";
$emailError = "";
$errorFname = "";
$errorLname = "";
$errorPhone = "";
$emailAddr = "";
$errorDesc = "";


function get_comment($fields, $connect) {

    if ($connect->connect_error)
    {
        die("Connection failed1: " . $connect->connect_error);
    } else {

        $num = ltrim($fields[1], "0");
        $sql = "SELECT * FROM MDesk.ticket_logs WHERE ticket_ref='$num' AND team_only= '0' ORDER BY datetime DESC ;";

        if(!$connect->query($sql))
        {
            die("Connection failed @ get: " . $connect->connect_error);
        } else {

            $res = mysqli_query($connect, $sql);
            $result = "<table class=\"table table-bordered rounded\" id=\"dataTable\" cellspacing=\"0\"><thead>
                        <tr class='bg-gradient-dark text-gray-200' >
                            <th>Timestamp</th> 
                            <th>Comment</th>
                            <th>From</th>                            
                        </tr>
                    </thead>
                    <tfoot><tr></tr></tfoot>
                    <tbody>";
            $first_row = true;
            while ($row = mysqli_fetch_assoc($res)) {
                if ($first_row) {
                    $result .= "<tr class='bg-gray-200 border-info'><td class='' style='width: 10%'>" . $row['datetime'] . "</td><td>" . $row['comment'] . "</td><td class='' style='width: 15%'>" . $row['sender'] . "</td></tr>";
                    $first_row = false;
                } else {
                    $result .= "<tr><td class='' style='width: 10%'>" . $row['datetime'] . "</td><td>" . $row['comment'] . "</td><td class='' style='width: 15%'>" . $row['sender'] . "</td></tr>";
                }
            }
            $result .= "</tbody>
                  </table>";
            //$connect->close();
            return $result;
        }
    }
}

function check_resubmit($num, $comment, $sender, $conn)
{
    $sql = "SELECT * FROM MDesk.ticket_logs WHERE ticket_ref='$num' AND team_only='0' ORDER BY datetime DESC LIMIT 1 ;";
    if (!$conn->query($sql)) {

        return true;
        //die("Connection failed1: " . $conn->connect_error);
    } else {
//        echo "<br>Checking";
        $res = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($res);

//        echo "<br>" . $row['sender'];
//        echo "<br>" . $row['comment'];
        if (($row['sender'] == $sender) && ($row['comment'] == $comment)) {
            //echo "<br> Repeated Comment";
            return true;
        } elseif ($comment =="") {
            //echo "<br> No Comment";
            return "Closed";
        }elseif (($row['sender'] == "SYSTEM") && ($row['comment'] == "Ticket Closed By Customer")){
            return true;
        }else {
            //echo "<br> new Comment";
            return false;
        }
    }
}
function team_address($conn){
    $sql = "SELECT primary_key FROM MDesk.users;";
    $return = array();
    if (!$conn->query($sql)) {
        return true;
        //die("Connection failed1: " . $conn->connect_error);
    } else {
        $res = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($res)) {
            array_push($return,$row['primary_key']);
        }
        return $return;
    }
}
function add_comment($fields, $connect)
{   $num = ltrim($fields[1], "0");
    if ($connect->connect_error) {
        die("Connection failed1: " . $connect->connect_error);
    } else {

       // echo 'assigned to ' . $fields[3];
        $check = check_resubmit($num, $fields[0], $fields[2], $connect);
        if ($check == "Closed"){
            return false;
        } else {
            if ($check) {
                //echo "Repeat";
                $connect->close();
                return true;
            } else {
                $sql = "insert into MDesk.ticket_logs (ticket_ref, comment, sender, action_cost, team_only, datetime) values ('$num', '$fields[0]', '$fields[2]', '0', '0', CURRENT_TIMESTAMP());";
                $comment = 'New Comment on ticket'. $num;
                if ($fields[2] = 'SYSTEM'){
                    $comment = $fields[0];
                }
                if ($fields[3] == "") {
                    $dest = team_address($connect);
                    foreach ($dest as $item) {
                        //echo 'unassigned';

                        $sql1 = "INSERT INTO MDesk.alerts (recipient_id, alert_msg, unread, date_time) VALUES ('$item', '$comment', 1, CURRENT_TIMESTAMP());";
                         $connect->query($sql1);
                        //echo $item;
                    }

                } else {

                    $dest = $fields[3];

                    $sql1 = "INSERT INTO MDesk.alerts (recipient_id, alert_msg, unread, date_time) VALUES ('$dest', '$comment', 1, CURRENT_TIMESTAMP());";
                    $connect->query($sql1);
                }


                if (!$connect->query($sql)) {
                    echo '<br>Connection failure';

                    return true;
                } else {
                    //echo '<br>Success';
                    $connect->close();
                    return true;
                }
            }
        }
    }

}

function customer_close($fields, $connect)
{
    if ($connect->connect_error) {
        return;
        //die("Connection failed1: " . $connect->connect_error);
    } else {
        $date = date_format($fields[3], "Y/m/d");
        $date1 = date("Y/m/d");
        $days_open = date_diff($date, strtotime($date1));
        $num = ltrim($fields[1], "0");
        $open = add_comment($fields, startConn());
        //$sql = "insert into MDesk.ticket_logs (ticket_ref, comment, sender, action_cost, team_only, datetime) values ('$num', '$fields[0]', 'SYSTEM', '0', '0', CURRENT_TIMESTAMP());";

        if ($open) {
            $sql1 = "UPDATE MDesk.work_tickets SET status = 'closed',  closed = CURRENT_TIMESTAMP(), opened_to_closed = '$days_open', total_time_open = '$days_open' WHERE TNum = '$num';";
            if (!$connect->query($sql1)) {
                //die("Connection failed when updating ticket status: " . $connect->connect_error);
                return "Error";
            } else {
                $connect->close();
                return "Success";
            }
        } else {
            return "Ticket Closed";
        }


    }
}
function loadtick($fields, $connect)
{
    if ($connect->connect_error)
    {
        die("Connection failed1: " . $connect->connect_error);
    } else {
//       echo "||ticket no. " . ltrim($fields[2], "0");
//        echo "||email :" . $fields[0] . "|||";
        $num = ltrim($fields[1], "0");
        //$sql = "SELECT * FROM MDesk.work_tickets WHERE TNum='$num' AND email='$fields[0]';";
        $sql = "SELECT * FROM MDesk.work_tickets LEFT JOIN MDesk.T_Category ON work_tickets.category = T_Category.Category_ID WHERE TNum='$num' AND email='$fields[0]';";
        if(!$connect->query($sql))
        {
            die("Connection failed2: " . $connect->connect_error);
        } else {
            //$sql = "SELECT * FROM work_tickets WHERE ORDER BY TNum DESC LIMIT 1;";
            $res = mysqli_query($connect, $sql);

            $result = mysqli_fetch_assoc($res);
            if($result['email'] == ""){
                return false;
            } else {
                if ($result['status'] == 'open') {
                    $result['status'] = 'Open';
                } else {
                    $result['status'] = 'Closed';
                }
                $phone = substr($result['phone'], 0, 3) . " . " . substr($result['phone'], 3, 3) . " . " . substr($result['phone'], 6, 4);
                $result['phone'] = $phone;
                return $result;
            }
        }
    }
}

if ($page_id === "ticketcheck") {

    $isProcessingForm = false;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $isProcessingForm = true;

        if ($isProcessingForm) {
            if (isset($_POST['comments'])){
                //echo "comments";
                if ($_POST['close'] == 'true'){
                    //echo "1";
                    $id_variables_Check = [$_POST['comments'], $_POST['num'],   $_POST['sender'] ,$_POST['opened'], $ticket['assignee']];
                    customer_close($id_variables_Check, startConn());

                    $_SESSION['log'] = get_comment($id_variables_Check, startConn());

                    $ticket = $_SESSION['result'];
                    $ticket['status'] = 'Closed';
                    $_SESSION['counter'] = 0;
                    unset($_POST['comments'], $_POST['num'],   $_POST['sender'], $_POST['close']);
                    $isProcessingForm = false;
                } else {
                    //echo '<br>2';
                    $id_variables_Check = [$_POST['comments'], $_POST['num'], $_POST['sender'], $ticket['assignee']];
                    add_comment($id_variables_Check, startConn());
                    $_SESSION['log'] = get_comment($id_variables_Check, startConn());
                    $ticket = $_SESSION['result'];
                    $_SESSION['counter'] = 0;
                    unset($_POST);
                    $isProcessingForm = false;
                }

            } else {
                // Assign Array Values to local variables
                $userEmail = $_POST['creatorEmail'];
                //$lname = $_POST['lastName'];
                $ticketnum = $_POST['ticketnumber'];

                $confirmation = $_POST['confirmation'];

                $id_variables_Check = [$userEmail, $ticketnum];
            }
        }
        if (empty($userEmail) || empty($ticketnum))
        {

            if (empty($userEmail)) {
                $emailError = "<div class='text-black-50'> Please Enter Email!!</div>";
//            }if (empty($lname)) {
//                $errorLname = "<div class='text-black-50'> Please Last Name!!</div>";
            }if (empty($ticketnum)) {
                $errorTicketnumber = "<div class='text-black-50'>Enter Ticket Number</div>";
            }
        }
        elseif($_SESSION['real_user'])
        {

            //Code for Ticket submission into SQL
            //result page for ticket displays with button going back
            $id_variables_Check = [$userEmail, $ticketnum];
            if (!isset($_SESSION['confirmation'])) {

                $ticket = loadtick($id_variables_Check, startConn());
                $comment_log = get_comment($id_variables_Check, startConn());
                if ($ticket == false) {
                    //echo "false";
                    unset($_SESSION['confirmation']);
                    unset($_SESSION['result']);
                    unset($_SESSION['counter']);
                    unset($_POST);
                    unset($_SESSION['real_user']) ;

                } else {
                    //echo "initiatl";
                    if ($ticket['TNum'] < 10) {
                        $val = '0000' . $ticket['TNum'];

                    } elseif ($ticket['TNum'] < 100) {
                        $val = '000' . $ticket['TNum'];
                    } elseif ($ticket['TNum'] < 1000) {
                        $val = '000' . $ticket['TNum'];
                    } else {
                        $val = '0' . $ticket['TNum'];
                    }
                    $ticket['TNum'] = $val;
                    $_SESSION['confirmation'] = true;
                    $_SESSION['counter'] = 0;

                    $_SESSION['log'] = $comment_log;
                    $_SESSION['result'] = $ticket;
                }
                } elseif ($_SESSION['counter'] < 6){
                //echo "init2";
                $confirmation = true;
                $ticket = $_SESSION['result'];
                $_SESSION['counter'] += 1;
//                echo '||' . $_SESSION['counter'];
                } else {
                    //echo "New Submission";
                    $confirmation = false;
                    $_SESSION['counter'] = 0;
                    unset($_SESSION['counter']);

                    unset($_SESSION['confirmation']);
                    unset($_SESSION['result']);
                    //                unset($_POST);
                    $id_variables_Check = [];
                    //                header("Location: ". get_url());
                    //                session_destroy();
                    //                ob_flush();
                }




        } else {
            //echo "not real";
            unset($_SESSION['real_user']) ;
        }
    } else{
        unset($_SESSION['confirmation']);
        unset($_SESSION['result']);
        unset($_SESSION['counter']);
        unset($_POST);

    }
}

