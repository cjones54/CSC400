<?php
$pagesDIR = "/";
//col-xl-3 col-lg-4 col-md-5 col-sm-6 mb-2 justify-content-between //card 1 class
//row justify-content-xl-center justify-content-lg-center justify-content-md-center justify-content-sm-center//
$cards =
"                
" . //Card Row .
"
            

                    <!-- Card body -->
                    <div class=\"col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-3 \">
                        <div class=\"card border-left-primary shadow h-100 py-2 justify-content-xl-center justify-content-lg-center justify-content-md-center justify-content-sm-center\">
                            <div class=\"card-body \">"
.// Submit Ticket

                                "
                                <div class=\"row justify-content-center\">
                                     
                              
                                    <div class='col-xl-3 col-lg-4 col-md-5 col-sm-6 mx-2 mb-2  justify-content-between'>                                                                      
                                        <a href=\" " . $pagesDIR . "ticketsubmit\" class=\"btn btn-primary btn-icon-split btn-lg align-items-center\">
                                            <span class=\"icon py-md-4 py-5 text-white-50 \">
                                              <i class=\" fas fa-exclamation-triangle\"></i>
                                            </span>
                                            <span class=\"text px-4\">Submit  a  Request </span>
                                        </a>                                        
                                    </div>
                                    
                                    
                                    "
 .//Request status button
                                    "
                                    <div class='col-xl-3 col-lg-4 col-md-5 col-sm-6 mx-2 mb-2 justify-content-between '>                                                                                                                                               
                                        <a href=\" " . $pagesDIR . "ticketcheckup\" class=\"btn btn-primary btn-icon-split btn-lg align-items-center \">
                                            <span class=\"icon py-md-4 py-5 text-white-50\">
                                              <i class=\"fas fa-arrow-alt-circle-right\"></i>
                                            </span>
                                            <span class=\"text\">Check Request Status</span>
                                        </a>                                                                                  
                                    </div>
                                    
                                
                                </div>                                                  
                                    
                                 
                             </div>
                         </div>
                    </div>
                                   
";
