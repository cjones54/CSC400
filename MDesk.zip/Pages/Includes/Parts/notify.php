<?php
$q = $_POST["q"];
$notificationCtr = 0;



$unreadEmailCtr = 0;



$timesinceRec = 0;

$test = 5;

echo $test;




