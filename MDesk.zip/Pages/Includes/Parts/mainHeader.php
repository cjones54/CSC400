<?php
$navbar = "";
$update_script = "";
$loggedin = "";
header('X-Frame-Options: SAMEORIGIN');



include_once "nav.php";
include "pageSwitch.php";

function validateLogin ($check){
    if(!$check){

        header("Location: /login");
    }
}

    $header =
        "
        <!DOCTYPE html>
        <html lang=\"en\">
        
        <head>
        
            <meta charset=\"utf-8\">
            
            <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">

            <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
            <title>" . $pageTitle . "</title>
        
            <!-- Custom fonts for this template-->
            <link href=\"/vendor/fontawesome-free/css/all.min.css\" rel=\"stylesheet\" type=\"text/css\">
            <link href=\"https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i\" rel=\"stylesheet\">
        
            <!-- Custom styles for this template-->
            <link href=\"/css/sb-admin-2.css\" rel=\"stylesheet\">
            <link href=\"/vendor/datatables/dataTables.bootstrap4.css\" rel=\"stylesheet\">
        </head>
        ";
//side nav bar container

//<meta http-equiv="X-UA-Compatible" content="IE=edge">
if ($page_id === 'main') {
        $navbar = "
        <!-- Sidebar -->
    <ul class=\"navbar-nav bg-gradient-primary sidebar sidebar-dark accordion\" id=\"accordionSidebar\">
            
        <!-- Sidebar - Brand -->
        <a class=\"sidebar-brand d-flex align-items-center justify-content-center\" href=\"/\">
            <div class=\"sidebar-brand-icon rotate-n-15\">
                <i class=\"fas fa-fw fa-home\"></i>
            </div>
            <div class=\"sidebar-brand-text mx-3\">" . $navCorner . "</div>
        </a>

        <!-- Divider -->
        

        <!-- Nav Item - Dashboard -->
       " . $loggedin . "

      

    </ul>
    ";
    } else {
        $navbar = "
        <!-- Sidebar -->
    <ul class=\"navbar-nav bg-gradient-primary sidebar sidebar-dark accordion\" id=\"accordionSidebar\">

        <!-- Sidebar - Brand -->
        <a class=\"sidebar-brand d-flex align-items-center justify-content-center\" href=\"/\">
            <div class=\"sidebar-brand-icon rotate-n-15\">
                <i class=\"fas fa-fw fa-home\"></i>
            </div>
            <div class=\"sidebar-brand-text mx-3\">" . $navCorner . "</div>
        </a>

        <!-- Divider -->
        <hr class=\"sidebar-divider my-0\">

        <!-- Nav Item - Dashboard -->
        <li class=\"nav-item active\">
            <a class=\"nav-link\" href=\"/\">
                <i class=\"fas fa-fw fa-tachometer-alt\"></i>
                <span>Back to Home</span></a>
        </li>

        <!-- Divider -->
        
              " . $loggedin . "

        <!-- Divider -->

    </ul>
";
    };

    $footer =
        "<!-- Footer -->
    <footer class=\"sticky-footer bg-white\">
        <div class=\"container my-auto\">
            <div class=\"copyright text-center my-auto\">
                <span>Copyright &copy; Maintenance Desk 2020</span>
            </div>
        </div>
    </footer> . $update_script";


$contentHeader =
    "
    <div class=\"d-sm-flex align-items-center justify-content-between mb-4\">
                <h1 class=\"h3 mb-0 text-gray-800\">" . $contentHeader1 . "</h1>
            </div>
    ";
