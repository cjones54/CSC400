<?php

$emailError = "";
$errorPassword = "";
include_once "captcha.php";

///////////////////////////////
function loaduser ($email, $ptext, $conn)
{

    if ($conn->connect_error) {
        die("Connection failed1: " . $conn->connect_error);
    } else {
        $e_mail = strtolower($email);
        $sql = "SELECT * FROM users WHERE email='$e_mail' LIMIT 1;";

        if (!$conn->query($sql)) {
            die("Connection failed Bad Conn: " . $conn->connect_error);
        } else {
            //$sql = "SELECT * FROM work_tickets WHERE ORDER BY TNum DESC LIMIT 1;";
            $res = mysqli_query($conn, $sql);
            $result = mysqli_fetch_assoc($res);
            $id = $result['primary_key'];
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                //ip from share internet
                $ip1 = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                //ip pass from proxy
                $ip1 = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip1 = $_SERVER['REMOTE_ADDR'];
            }


            $failed = $result['failed_logins'];

            if ($failed > 14) {
                $ip = 'Re-attempt on locked out account from: ' . $ip1;
                $sql3 = "INSERT INTO activity_log (activity_type_id, activity, actor_id, timestamp) VALUES ( '0', '$ip', '$id', CURRENT_TIMESTAMP());";
                $sql4 = "INSERT INTO notifications (user_id, subject,  message, timestamp, sender, read) 
                            VALUES ('$id', 'Account Lockout','Your Account was locked out. Someone attempted to access your account but failed.', CURRENT_TIMESTAMP(), 'SYSTEM', '0');";
                //$sql5 = ";";
                $conn->query($sql3);
                $conn->query($sql4);
                $conn->close();
                return "Lockout";
            } else {
                //password_verify($pass, $hash)
                if (password_verify($ptext, $result['password'])) {
                    $ip = 'Login Success From: ' . $ip1;
                    $sql3 = "insert into activity_log (activity_type_id, activity, actor_id, timestamp) values ( '0', '$ip', '$id', CURRENT_TIMESTAMP());";
                    $sql4 = "UPDATE users SET  last_login = CURRENT_TIMESTAMP(), failed_logins = '0' WHERE primary_key = '$id';";
                    $conn->query($sql3);
                    $conn->query($sql4);
                    $conn->close();
                    return $result;
                } else {
                    $failed += 1;
                    if ($failed > 14) {
                        $ip = 'Maxed Failed Login Attempts Reached From: ' . $ip1 . " since last successful login, account access locked.";
                        $sql3 = "INSERT INTO activity_log (activity_type_id, activity, actor_id, timestamp) VALUES ( '0', '$ip', '$id', CURRENT_TIMESTAMP());";
                        $sql4 = "UPDATE users SET failed_logins = '$failed', locked_out = '1', lockout_datetime = CURRENT_TIMESTAMP(), lockout_ip = '$ip1' WHERE primary_key = '$id';";

                        $conn->query($sql3);
                        $conn->query($sql4);

                        $conn->close();

                        return "Lockout";
                    }


                    $ip = 'Failed Login Attempt #' . $failed . ' From: ' . $ip1 . " since last successful login";
                    $sql3 = "insert into activity_log (activity_type_id, activity, actor_id, timestamp) values ( '0', '$ip', '$id', CURRENT_TIMESTAMP());";
                    $sql4 = "UPDATE users SET failed_logins = '$failed' WHERE primary_key = '$id';";

                    $conn->query($sql3);
                    $conn->query($sql4);

                    $conn->close();

                    return "Bad Login";
                }

            }
        }
    }
}

//Login Form Processing
if ($page_id === "login") {
    //Determine if we're supposed to process th form
    $isProcessingForm = false; //Sets whether we're supposed to do the processing

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo $_SESSION['REQUEST_METHOD'];
        $isProcessingForm = true;
    }

    if ($isProcessingForm) {
        // Assign Array Values to local variables
        $userEmail = $_POST['userEmail'];
        $password = $_POST['userPassword'];
        $confirmation = false;

        if (empty($userEmail) || empty($password)) {
            // Search and announcement that input was not entered
            if (empty($userEmail)) {
                $emailError = "<div class='text-black-50' color='red'> Enter Email!!</div>";
            }
            if (empty($password)) {
                $errorPassword = "<div>Enter Password!!</div>";
            }

        } elseif (!empty($userEmail) && !empty($password)) {
            $_SESSION['valid_logon'] = true;

            if ($_SESSION['real_user']) {

                $account = loaduser($userEmail, $password, startConn());

                if ($account != "Bad Login" && $account != "Lockout") {
                    setSession($account['email'], true, $account['fname'], $account['lname'], $account['failed_logins'], $account['admin'], $account['primary_key']);
                } elseif ($account === "Bad Login") {
                    $errorPassword = "<div> Bad Login </div>";
                } elseif ($account === "Lockout") {
                    $errorPassword = "<div> Account Locked Out </div>";
                } else {
                    $errorPassword = "<div> Cannot Process at this time</div>";
                }
            }
        } else {
            $userEmail = "";
            $password = "";
            $emailError = "";
            $errorPassword = "";
        }
    }
}