<?php
switch ($page_id) {
    case "main":
        $pageTitle = "MDesk Home";
        $contentHeader1 = "Property News";
        $_SERVER['PHP_SELF'] = "/";
        break;
    case "login":
        $pageTitle = "Login";
        $contentHeader1 = "Login";
        $_SERVER['PHP_SELF'] = "/login";
        break;
    case "dashboard":
        $pageTitle = "Dashboard";
        $contentHeader1 = "Ticket Dashboard";
        $_SERVER['PHP_SELF'] = "/TeamDashboard";
        break;
    case "mytickets":
        $pageTitle = "My Tickets";
        $contentHeader1 = "My Tickets";
        $_SERVER['PHP_SELF'] = "/mytickets";
        break;
    case "ticketsub":
        $pageTitle = "Submit Ticket";
        $contentHeader1 = "Ticket Creation";
        $_SERVER['PHP_SELF'] = "/ticketsubmit";
        break;
    case "ticketcheck":
        $pageTitle = "Ticket Checkup";
        $contentHeader1 = "Ticket Checkup";
        $_SERVER['PHP_SELF'] = "/ticketcheckup";
        break;
    case "settings":
        $pageTitle = "Settings";
        $contentHeader1 = "Settings";
        $_SERVER['PHP_SELF'] = "/Settings";
        break;
    case "add_news":
        $pageTitle = "Add News";
        $contentHeader1 = "Update Property News";
        $_SERVER['PHP_SELF'] = "/announcements";
        break;
    case "reports":
        $pageTitle = "Reports";
        $contentHeader1 = "Reporting";
        $_SERVER['PHP_SELF'] = "/reports";
        break;
    case "user_activity":
        $pageTitle = "Activity";
        $contentHeader1 = "User Activity";
        $_SERVER['PHP_SELF'] = "/user_activity";
        break;
    case "ticket_page":
        $pageTitle = "Ticket #" . $t_id;
        $contentHeader1 = "Details:";
        $_SERVER['PHP_SELF'] = "/ticket";
        break;
    default:
        $pageTitle = "Undefined";
        $contentHeader1 = "Uh oh";


}