<?php
$containerstart =
"
    <div class=\"col\" >
        <div class=\"card shadow mb-4\">
            
              <div class=\"card-header py-3\">
                <h6 class=\"m-0 font-weight-bold text-primary\">Flyers</h6>
              </div>
            
              <div class=\"card-body col-md col-sm-1\">

";
//<img src='/img/Mountains.jpg' style=\"width:100%;height:max-content ;center;\">
$containerstop =
    "
            </div>
        </div>
    </div>   
    ";