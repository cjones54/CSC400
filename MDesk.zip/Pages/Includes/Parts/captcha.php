<?php
require_once 'Includes/DataLayer/configuration.php';
$valid_Post = false;
$real_user = false;
$statusMsg = '';



$captcha_form = "
    <div class='col-auto'><style> 
@media screen and (max-width: 575px){ 
.g-recaptcha {
transform:scale(0.77);
-webkit-transform:scale(0.77);
transform-origin:0 0;
-webkit-transform-origin:0 0;
} 
} 
</style><div class=\"g-recaptcha \" data-sitekey=\"$site_key\"></div></div>
    "
;

$captcha_script = "
    <script src=\"https://www.google.com/recaptcha/api.js\"></script>
";


// Validate Captcha
    if(isset($_POST['submit'])){

        // Validate reCAPTCHA box
        if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){
            // Google reCAPTCHA API secret key


            // Verify the reCAPTCHA response
            $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$_POST['g-recaptcha-response']);

            // Decode json data
            $responseData = json_decode($verifyResponse);

            // If reCAPTCHA response is valid
            if($responseData->success){
                // Posted form data
                $_SESSION['real_user'] = true;

                $statusMsg = '<div> Success</div>';
            }else{
                $statusMsg = '<div> Robot verification failed, please try again.</div>';
            }
        }else{
            $statusMsg = '<div> Please check on the reCAPTCHA box.</div>';
        }
    }else{
        $statusMsg = '';
    };

