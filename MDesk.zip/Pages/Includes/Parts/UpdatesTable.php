<?php
//include_once 'Includes/DataLayer/SQLinterface.php';


////function querynews($conn)
////{
////    if ($conn == "ERROR"){
////        return "There was an error connecting this page";
////    } else {
////        // 2. Create the SQL statement for retrieving students
////        $sql = "SELECT * FROM MDesk.news_table;";
////
////        // 3. Retrieve the results
////        $result = $conn->query($sql);
////
////        $conn->close();
////        return $result;
////    }
////}
////
////function newsTable($page_id) {
////
////    //echo $page_id;
////    $result = querynews(startConn());
////    if ($result === 'ERROR')
////    {
////        $input = "<tr><td>ERROR</td><td>ERROR/td><td>ERROR</td><td>ERROR</td></tr> ";
////        echo 'error';
////    } else {
////        $input = "";
////        //4. Loop over the results and output to the screen
////        while ($row = mysqli_fetch_assoc($result)) {
////            $input .= "<tr><td>" . $row['title'] . "</td><td>" . $row['content'] . "</td><td> " . $row['date'] . "</td><td>" . $row['added_by'] . "</td></tr> ";
////        }
////    }
////
////    $tablereturn =
////        "
////            <div class=\"col-xl-12 col-lg-12\">
////                <div class=\"card shadow mb-4\">
////
////                      <div class=\"card-header py-3\">
////                        <h6 class=\"m-0 font-weight-bold text-primary\">Property News</h6>
////                      </div>
////
////                      <div class=\"card-body\">
////                        <div class=\"table-responsive\">
////                          <table class=\"table table-bordered\" id=\"dataTable\"  cellspacing=\"0\">
////                            <thead>
////                                <tr>
////                                    <th>Title</th>
////                                    <th>Details</th>
////                                    <th>Date Posted</th>
////                                    <th>Added by</th>
////
////                                </tr>
////                            </thead>
////                            <tfoot>
////                                <tr>
////
////                                </tr>
////                            </tfoot>
////                            <tbody>
////                                 " . $input ."
////                                <tr>
////                                  <td>Summer Break</td>
////                                  <td>A description of what is <br> being announced will go here</td>
////
////
////                                  <td>Today</td>
////
////                                  <td>Dev</td>
////
////                                </tr>
////                           </tbody>
////                          </table>
////                        </div>
////                      </div>
////                </div>
////            </div>
////        ";
////    return $tablereturn;
////}
//
function tickets($id, $connect){


// 1. Establish connection
    $sql = "SELECT * FROM MDesk.work_tickets WHERE status='open';";


    if ($connect->connect_error) {
        die("Connection failed: " . $connect->connect_error);

    } else {
        $result = $connect->query($sql);
        $input = "";
        //4. Loop over the results and output to the screen
        while ($row = mysqli_fetch_assoc($result)) {
            $assign = $row['assignee'];
            $t_id = $row['TNum'];
            $action = "<form action='/ticket' method=\"POST\">

                            <input type='hidden' name='t_id' value='$t_id'>
                            <input type = \"submit\" name=\"submit\" value =\"Work >>\" class=\"btn-sm btn-primary btn-user btn-block mb-2\"></form> ";
            if ($row['assignee'] =='unassigned'){
                $assign = "<form action='/ticket' method=\"POST\">
                                <input type='hidden' name='t_id' value='$t_id'>
                                <input type='hidden' name='assignment' value='50'>
                                <input type = \"submit\" name=\"submit\" value =\" Assign to Self\" class=\"btn-sm btn-primary btn-user btn-block mb-2\"></form> ";
                $action = "This ticket needs to be assigned!";
            }

            $input .= "<tr><td style='text-align: center'>" . $t_id . "</td><td style='text-align: center'>" . $row['category'] . "</td><td style=\"width:60%;\"> " . $row['description'] . "</td><td style='text-align: center'>" . $assign . "</td><td>" . $row['opened'] . "</td><td>" . $action . "</td></tr> ";
        }
    }
    $connect->close();
    return $input;
}


function my_tickets ($id, $conn){

    $sql = "SELECT * FROM MDesk.work_tickets WHERE status='open' AND assignee_id='$id';";

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);

    } else {
        $result = $conn->query($sql);

        $input = "";
        //4. Loop over the results and output to the screen
        while ($row = mysqli_fetch_assoc($result)) {
            $t_id = $row['TNum'];
            $assign = $row['assignee'];
            $action = "<form action='/ticket' method=\"POST\">
                            <input type='hidden' name='t_id' value='$t_id'>
                            <input type = \"submit\" name=\"submit\" value =\"Work >>\" class=\"btn-sm btn-primary btn-user btn-block\" ></form> ";
            $input .= "<tr><td style='text-align: center'>" . $t_id . "</td><td style='text-align: center'>" . $row['category'] . "</td><td style=\"width:60%;\"> " . $row['description'] . "</td><td>" . $assign . "</td><td>" . $row['opened'] . "</td><td>" . $action . "</td></tr> ";
        }
    }
    $conn->close();
    return $input;
}

function useractivity($id, $conn){

// 1. Establish connection
    $sql = "SELECT * FROM MDesk.activity_log WHERE actor_id='$id' ORDER BY timestamp DESC;";

;
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $result = $conn->query($sql);
        $input = "";
        $count = 1;
        //4. Loop over the results and output to the screen
        while ($row = mysqli_fetch_assoc($result)) {
            $input .= "<tr><td>$count</td><td>" . $row['activity'] . "</td><td>" . $row['timestamp'] . "</td></tr> ";
            $count += 1;
        }
        $conn->close();
    }

    return $input;
}

$ticketTable =
    "
    <div class=\"col-xl-12 col-md-12\">
        <div class=\"card shadow mb-4\">
              <div class=\"card-header py-3\">
                <h6 class=\"m-0 font-weight-bold text-primary\">Ticket Browser</h6>
              </div>

              <div class=\"card-body\">
                <div class=\"table-responsive\">
                  <table class=\"table table-bordered\" id=\"dataTable\" cellspacing=\"0\">
                    <thead>
                        <tr>
                            <th>Ticket No.</th>
                            <th>Category</th>
                            <th style=\"width:30%;\">Summary</th>
                            <th>Assignee</th>
                            <th>Date Submitted</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>

                        </tr>
                    </tfoot>
                    <tbody>
                       " . tickets($_SESSION['user_id'], startConn()) ."
                   </tbody>
                  </table>
                </div>
              </div>
        </div>
    </div>
";

$my_ticketTable =
    "
    <div class=\"col-xl-12 col-md-12\">
        <div class=\"card shadow mb-4\">
              <div class=\"card-header py-3\">
                <h6 class=\"m-0 font-weight-bold text-primary\">Ticket Browser</h6>
              </div>

              <div class=\"card-body\">
                <div class=\"table-responsive\">
                  <table class=\"table table-bordered\" id=\"dataTable\" cellspacing=\"0\">
                    <thead>
                        <tr>
                            <th>Ticket No.</th>
                            <th>Category</th>
                            <th style=\"width:30%;\">Summary</th>
                            <th>Assignee</th>
                            <th>Date Submitted</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>

                        </tr>
                    </tfoot>
                    <tbody>
                        ". my_tickets($_SESSION['user_id'], startConn()) . "
                   </tbody>
                  </table>
                </div>
              </div>
        </div>
    </div>
";
$reportTable =
    "

    <div class=\"col-xl-12 col-md-12\">
        <div class=\"card shadow mb-4\">

              <div class=\"card-header py-3\">
                <h6 class=\"m-0 font-weight-bold text-primary\">Ticket Browser</h6>
              </div>

              <div class=\"card-body\">
                <div class=\"table-responsive\">
                  <table class=\"table table-bordered\" id=\"dataTable\" width='100%' cellspacing=\"0\">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Creator</th>
                            <th>Summary</th>
                            <th>Date Submitted</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                        </tr>
                    </tfoot>
                    <tbody>
              
                   </tbody>
                  </table>
                </div>
              </div>
        </div>
    </div>

";

$useractivitytable = "
<div class=\"col-xl-12 col-md-12\">
        <div class=\"card shadow mb-4\">

              <div class=\"card-header py-3\">
                <h6 class=\"m-0 font-weight-bold text-primary\">Your Activity</h6>
              </div>

              <div class=\"card-body\">
                <div class=\"table-responsive\">
                  <table class=\"table table-bordered\" id=\"dataTable\" width='100%' cellspacing=\"0\">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Activity</th>
                            <th>Occurence</th>

                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                        </tr>
                    </tfoot>
                    <tbody>
                        ". useractivity($_SESSION['user_id'], startConn()) . "
                   </tbody>
                  </table>
                </div>
              </div>
        </div>
    </div>
";