<?php
//$page_id = "processing";
include_once "captcha.php";
//include_once "file_upload.php";
///////////////////////////////
$id_variables_Check = "";
$errorContent = "";
$TitleError = "";
$content = "";
$title = "";
$allowTypes = array('jpg','png','jpeg','gif','pdf');
$statusMsg = '';

$confirmation = False;

function addnews($title, $content, $author, $dir, $conn)
{

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
    else {
        $sql = "insert into MDesk.news_table (`title`, `content`, `date`, `added_by`, `img_path`) values ('$title', '$content', CURRENT_TIMESTAMP(), '$author', '$dir');";

        if(!$conn->query($sql))
        {
            die("DAMMIT");
        }
        else{
        $conn->close();
        }

    }
}


if ($page_id === "add_news") {
    //Determine if we're supposed to process th form
    //Sets whether we're supposed to do the processing
    $isProcessingForm = false;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $isProcessingForm = true;

        if ($isProcessingForm) {
//            echo "| processing";
            // Assign Array Values to local variables
            $content = $_POST['content'];
            $title = $_POST['title'];
            $creator = $_POST['creator'];
            //$loadfile = $_POST['file'];
            $targetDir = "../uploads/";
            $uploadOk = 1;
            $check = $_FILES['file']['size'];;
            $fileTMP = $_FILES["file"]["tmp_name"];
            $fileName = $_FILES["file"]["name"];
            $targetFilePath = $targetDir.$fileName;
            $fileType = strtolower(pathinfo($fileName,PATHINFO_EXTENSION));
//            echo "| Filesize = " . $check;
            //echo "||Current DIR: " . __DIR__;
//            echo "| Filename = ".$fileName;
//            echo "| FileTMP = ".$fileTMP;
//            echo "| Filepath = " . $targetFilePath;
//            echo "| File Type = " . $fileType;
//            echo "|| Sys Err 1: " . $_FILES['file']['error'];
        }

        if (empty($title) || empty($content)) {
            //echo "| Empty something";
            // Validate fields
            if (empty($title)) {
                $TitleError  = "<div class='text-black-50' color='red'>Give it a Title!</div>";
            }
            if (empty($content)) {
                $errorContent= "<div>Content Needed!!</div>";
            }
        }
        //echo $isProcessingForm . "step 3 empty";
        //Confirmation that required variables are all entered
        elseif ($_SESSION['real_user']) {

            //$id_variables_Check = [$title, $content, $creator];
            if (in_array($fileType, $allowTypes)) {

               //move_uploaded_file($fileTMP, $targetFilePath);
                if(move_uploaded_file($fileTMP, $targetFilePath)) {

                    addnews($title, $content, $creator, '/uploads/'.$fileName, startConn());
                    $confirmation = true;
                }
                else {

                    echo "| Upload failed - ";
                    echo "| Failed for " . $fileName;
                    echo "|| Sys Err: " . $_FILES['file']['error'];
                }
            } else{

                echo " | FileType: " . $fileType . " not accepted!!!";
            }



        }
    }
}

//
//$target_dir = "uploads/";
//$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
//$uploadOk = 1;
//$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
//// Check if image file is a actual image or fake image
//if(isset($_POST["submit"])) {
//    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
//    if($check !== false) {
//        echo "File is an image - " . $check["mime"] . ".";
//        $uploadOk = 1;
//    } else {
//        echo "File is not an image.";
//        $uploadOk = 0;
//    }
//}