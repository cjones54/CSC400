<?php

function newuser($password, $conn)
{


    $password1 = password_hash($password, PASSWORD_DEFAULT);

    if ($conn->connect_error)
    {
        die("Connection failed1: " . $conn->connect_error);
    } else {

        $sql = "insert into users (lname, fname, usrname, password, email, ticket_count, last_login, failed_logins, password_last_set) values ('last2', 'first1', 'Admin', '$password1', 'team1@adm.com','0', CURRENT_TIMESTAMP(), '0', CURRENT_TIMESTAMP());";



        if(!$conn->query($sql))
        {
            die("Connection failed2: " . $conn->connect_error);
        } else {
            //$sql = "SELECT * FROM work_tickets WHERE ORDER BY TNum DESC LIMIT 1;";

            echo "Input successful";
            if (password_verify($pass, $hash)) {
                echo "<br> First Options: " ;
                $conn->close();
            } elseif (password_verify($password1, PASSWORD_DEFAULT)) {
                echo "<br> Second Option ";
                $conn->close();
            } else {
                echo "<br> Third Option";
                $conn->close();
            }
            $conn->close();
        }
    }
}

newuser(startConn());

function change_password()
{

}

