<?php
include_once 'SQLinterface.php';



// var_dump($connection);
function querynews($conn)
{
    if ($conn == "ERROR") {
        return "There was an error connecting this page";
    } else {
        // 2. Create the SQL statement for retrieving students
        $sql = "SELECT * FROM  MDesk.news_table;";

        // 3. Retrieve the results
        $result = $conn->query($sql);

        $conn->close();
        return $result;
    }
}
function addnews($conn, $title, $content, $author)
{
    echo "here";
    if ($conn == "ERROR") {
        return "There was an error connecting this page";
    } else {
        // 2. Create the SQL statement for retrieving students
        //$datetime = date('Y-m-d H:i:s');
        //$sql = "INSERT INTO news_table (update_id, title, content, date, added_by) VALUES (generated, " . $title . "," . $content . ", generated , ".$author .");";
        $sql = "insert into news_table (update_id, title, content, date, added_by) values ('generated', 'null', 'null', 'null', 'null');";
        // 3. Retrieve the results".   $datetime . "
        echo "here2";

        $conn->query($sql);
        echo "here3";


    }
}