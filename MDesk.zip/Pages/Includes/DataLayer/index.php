<?php
require 'redirect.php';
header("Location: $loc");
