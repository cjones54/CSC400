<?php
// Connect to our MySQL database using the mysqli object
//require_once "SQLinterface.php";



$year1 = "2020";
$year2 = "2020";
$month1 = "07";
$month2 = "07";
$day1 = 19;
$day2 = 26;
$date1 = "2020-07-19";
$date2 = "2020-07-26";
function standard_ticket_breakdown($connection)
{

    $date1 = "2020-07-19";
    $date2 = "2020-07-26";

    $categorysql = "SELECT * FROM MDesk.T_Category;";
    $usersql = "SELECT * FROM MDesk.users;";
    $sql = "SELECT * FROM MDesk.work_tickets WHERE opened BETWEEN '$date1' AND '$date2';";

    $user_res = mysqli_query($connection, $usersql);
    $cat_res = mysqli_query($connection, $categorysql);
    $result = mysqli_query($connection, $sql);

    $total_open = 0;
    $total_closed = 0;
    $total_unassigned = 0;

    $analysis_per_user = array(array('Team User', 'Total Tickets', 'Total Open', 'Total Closed', 'System Total Tickets'));
    $analysis_by_ticket_status = array(array('Total Tickets', 'Total Closed', 'Total Open', 'Total Unassigned'));

    $count_by_issue = 0;
    $count_over_time = 0;

    $user_list = array();
    while ($row = mysqli_fetch_assoc($user_res)) {
        array_push($user_list, $row);

    }
    $cat_list = array();
    while ($row = mysqli_fetch_assoc($cat_res)) {
        array_push($cat_list, $row);

    }


    $data = array();
    $userCounts = array();

    $ticket_count = 0;

    while ($row = mysqli_fetch_assoc($result)) {
        array_push($data, $row);
        if ($row['status'] === 'open') {
            $total_open += 1;
        } else {
            $total_closed += 1;
        }
        if ($row['assignee'] === 'unassigned') {
            $total_unassigned += 1;
        }
        $ticket_count += 1;
    }
    array_push($analysis_by_ticket_status, array($ticket_count, $total_closed, $total_open, $total_unassigned));
    foreach ($user_list as $user) {
        $count_by_user = 0;
        $assigned_to_user_open = 0;
        $closed_by_user = 0;
        foreach ($data as $ticket) {
            if ($user['usrname'] == $ticket['assignee'] && $ticket['status'] = 'open') {
                $count_by_user += 1;
            } elseif ($user['primary_key'] == $ticket['assignee'] && $ticket['status'] == 'closed') {
                $count_by_user += 1;
                $closed_by_user += 1;
            }
        }
        array_push($analysis_per_user, array($user['fname'], $count_by_user, $assigned_to_user_open, $closed_by_user, $ticket_count));
    }

    mysqli_close($connection);
    return $analysis_by_ticket_status;
}
$graph_data = standard_ticket_breakdown(startConn());
$labels = json_encode($graph_data[0]);
$data1 = json_encode($graph_data[1]);



$bargraph = "
              <div class=\"col-xl-8 col-lg-8\">
                <div class=\"card-header py-3\">
                  <h6 class=\"m-0 font-weight-bold text-primary\">Tickets by Status</h6>
                </div>
                <div class=\"card-body\">
                  <div class=\"chart-bar\">
                    <canvas id=\"myChart\"></canvas>
                  </div>
                  
                </div>
              </div>
              
             ";
//$colors = array(
//    'rgba(255, 99, 132, 0.2)',
//    'rgba(54, 162, 235, 0.2)',
//    'rgba(255, 206, 86, 0.2)',
//    'rgba(75, 192, 192, 0.2)',
//    'rgba(153, 102, 255, 0.2)',
//    'rgba(255, 159, 64, 0.2)'
//);
//$borders = array(
//    'rgba(255, 99, 132, 1)',
//    'rgba(54, 162, 235, 1)',
//    'rgba(255, 206, 86, 1)',
//    'rgba(75, 192, 192, 1)',
//    'rgba(153, 102, 255, 1)',
//    'rgba(255, 159, 64, 1)'
//
//);
//foreach ($graph_data[0] as $key){
//    $labeled = json_encode($key);
//    echo $labeled;
//}
//foreach ($graph_data[1] as $key){
//    $dated = json_encode($key);
//}

$bargraphscript = "
<script>
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: " . $labels. " ,
            datasets: [{
                label: '# Of Tickets',
                data: " . $data1 . ",
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
                     
            }],
            
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
    </script>";







