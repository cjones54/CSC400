<?php

function logIpAddr($page, $conn){
    $protocol = $_SERVER['SERVER_PROTOCOL'];
    $https = $_SERVER['HTTPS'];
    $port = $_SERVER['SERVER_PORT'];
    $ip2 = $_SERVER['HTTP_X_FORWARDED_FOR'];
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];

    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

    }else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }


// 1. Establish connection

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    else {
        $sql = "insert into MDesk.visitors (ip_addr, internet_ip, protocol, HTTPS, port, page, timestamp) values ('$ip','$ip2','$protocol','$https','$port','$page', CURRENT_TIMESTAMP());";

        if(!$conn->query($sql))
        {
            die("DAMMIT");
        }
        else{
            $conn->close();
        }

    }
}