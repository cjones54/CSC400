<?php

function get_email_config(){
    require 'configuration.php';

    $config = array($STATIC_SMTP, $STATIC_USER, $STATIC_PASS);
    return $config;
}


function get_db_config(){
    require 'configuration.php';

    $config = array($host, $username, $password, $db, $port);

    return $config;

}
function get_url(){
    require 'configuration.php';
    $config = $protocol."://".$root;
    return $config;
}
function startConn(){

    $config = get_db_config();

    $conn = new mysqli($config[0], $config[1], $config[2], $config[3], $config[4]);

    return $conn;
}