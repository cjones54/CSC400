<?php
//require_once 'SQLinterface.php';
//
//function activity_logging() {
//    $sql =" insert into MDesk.activity_log (activity_id, activity_type_id, actor_id, timestamp) values ('generated', 'null', 'null', 'null');";
//
//}

function assign_ticket($ticket_id, $id, $connect)
{
    $sql = "SELECT fname FROM MDesk.users WHERE primary_key = '$id';";



    if ($connect->connect_error){
        return "There was an error connecting this page";
    } else {

        // 3. Retrieve the results
        $result = $connect->query($sql);
        $row = mysqli_fetch_assoc($result);
        $assign = $row['fname'];

    }


    $sql1 = "UPDATE MDesk.work_tickets SET assignee = '$assign', date_assigned = CURRENT_TIMESTAMP TNum = '$ticket_id';";

    if($connect->query($sql1))
    {
        return 1;
    } else {
        $error = "There was an error processing the action";
        echo $error;
        return 0;
    }
}