<?php

function numberSQLtest($value){
    if(is_numeric($value)){
        return true;
    } else {
        return false;
    }
}

function checkSQLstring ($string){
    if (!stristr($string, '; --')){
        return;
    }
}