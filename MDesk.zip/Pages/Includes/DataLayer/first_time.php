<?php
require 'first_time_deployment.php';

echo create_tables($tables, startConn());
echo newuser("20P@SSword20!", startConn());