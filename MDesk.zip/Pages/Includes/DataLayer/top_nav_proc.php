<?php
//include_once 'SQLinterface.php';



function get_alerts($id){
//    echo 'trying to get_alerts';
    $host = "localhost";
    $db = "MDesk";
    $username = "dev";
    $password = 'P@$$word12';


    $conn = new mysqli($host, $username, $password, $db);
    $sql = "SELECT * FROM MDesk.alerts WHERE recipient_id='$id' ORDER BY date_time DESC;";


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $result = $conn->query($sql);
        $input = "    <li class=\"nav-item dropdown no-arrow mx-1\">
    <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"alertsDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
        <i class=\"fas fa-bell fa-fw\"></i>
        <!-- Counter - Alerts -->
        <span id='test' class=\"badge badge-danger badge-counter\"></span>
    </a>
<!-- Dropdown - Alerts -->
<div class=\"dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in\" aria-labelledby=\"alertsDropdown\">
<h6 class=\"dropdown-header\">
    Alerts Center
</h6>";
//        echo 'Querying <br>';
        while ($row = mysqli_fetch_assoc($result)) {
              //$date = strtotime(($row['date_time']));
             if ($row['unread'] == "1"){
                    $input .=  "
                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">
                                            <div class=\"mr-3\">
                                                <div class=\"icon-circle bg-primary\">
                                                <i class=\"fas fa-exclamation text-white\"></i>
                                                </div>
                                            </div>
                                            <div>

                                    <div class=\"small text-gray-500\">" . $row['recipient'] ."</div>
                                <span class=\"font-weight-bold\">" . $row['alert_msg'] . "</span></div></a>";
             } else{
                 $input .=  "
                                <a class=\"dropdown-item d-flex align-items-center bg-light\" href=\"#\">
                                            <div class=\"mr-3\">
                                                <div class=\"icon-circle bg-primary\">
                                                <i class=\"fas fa-exclamation text-white\"></i>
                                                </div>
                                            </div>
                                            <div>

                                <div class=\"small text-gray-500\">" . $row['date_time']  ."</div>
                                <span class=\"text-gray-500\">" . $row['alert_msg'] . "</span></div></a>";
             }






        }
        $input .= "<a class=\"dropdown-item text-center small text-gray-500\" href=\"/alerts\">Show All Alerts</a>
                                                                        </div>
                                                                        </li>";
        $conn->close();
    }
//    echo   '<br>' . $input;
//    echo   '<br>' . $id;
//    //echo   '<br>' . $input;
    return $input;
}

