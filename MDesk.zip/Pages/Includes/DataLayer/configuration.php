<?php



/**
 * Enter config for email below
 * Leave blank to not use email
 */
$STATIC_SMTP = '';//ENTER SMTP Address of SERVER

$STATIC_USER = '';//Enter the username of the email account@domain

$STATIC_PASS = '';//Enter Password for above Account

/**
 * Below are configurations for Google reCaptcha
 *
 * Leaving these default will leave captcha off
 *
 * (Unless you have a sitekey/secret key, leave it at this setting)
 *
 */

$site_key = "NONE";


$secretKey = 'NONE';


/**
 * Below Are Database Settings for MySQL
 *
 * This uses one login to a MySQL
 *
 * Ensure the ports are open on the host
 *
 */

$host = "localhost";        // Specify the DB Host (IP Address) or leave local host

$port = '3306';             /** Port number accessing MySQL >>> !!Don't change!! Unless you have    *
                              *   explictly changed the default port of your Database               **/

$db = "DBName";              // Name of DB (Schema)

$username = "root";          // Username of MySQL User

$password = 'Password';   // Password of MySQL User



























if($site_key == 'NONE' && $secretKey == 'NONE'){
    $_SESSION['real_user'] = true;
}