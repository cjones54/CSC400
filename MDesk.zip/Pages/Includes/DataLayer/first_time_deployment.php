<?php
require 'SQLinterface.php';



$sql = "create table T_Category
(
    Category_ID int auto_increment
        primary key,
    cat_title   text     null,
    Description longtext null
);";

$sql1 ="create table activity_log
(
    activity_id      int auto_increment
        primary key,
    activity_type_id int      null,
    activity         text     null,
    actor_id         int      null,
    timestamp        datetime null
);";

$sql2 ="create table alerts
(
    alert_id     int auto_increment,
    recipient_id int      null,
    alert_msg    text     null,
    unread       int      null,
    date_time    datetime null,
    constraint alerts_alert_id_uindex
        unique (alert_id)
);";

$sql3 ="alter table alerts
    add primary key (alert_id);";

$sql4 ="create table ip_trust_score_table
(
    ip_id                 int auto_increment,
    ip_address            text          null,
    site_connects         int           null,
    num_users             int           null,
    successful_logins     int           null,
    failed_login_attempts int           null,
    lockouts              int           null,
    real_user_verify      int           null,
    trust_level           int default 5 null,
    constraint ip_trust_score_table_ip_id_uindex
        unique (ip_id)
);";

$sql5 ="alter table ip_trust_score_table
    add primary key (ip_id);";

$sql6 ="create table news_table
(
    update_id int auto_increment
        primary key,
    title     text      null,
    content   longtext  null,
    date      timestamp null,
    added_by  text      null,
    img_path  text      null
);";

$sql7 ="create table notifications
(
    not_id    int auto_increment
        primary key,
    user_id   int        null,
    subject   text       null,
    message   longtext   null,
    timestamp datetime   null,
    sender    text       null,
    `read`    tinyint(1) null
);";

$sql8 ="create table ticket_logs
(
    log_id      int auto_increment
        primary key,
    ticket_ref  int               not null,
    comment     longtext          null,
    sender      text              null,
    action_cost decimal           null,
    team_only   tinyint(1)        null,
    work_order  decimal default 0 null,
    datetime    timestamp         null
);";

$sql9 ="create table users
(
    primary_key       int auto_increment
        primary key,
    lname             text       not null,
    fname             text       not null,
    usrname           text       not null,
    password          longtext   not null,
    email             text       not null,
    ticket_count      int        not null,
    last_login        datetime   null,
    failed_logins     int        not null,
    password_last_set datetime   null,
    admin             tinyint(1) null,
    locked_out        tinyint(1) not null,
    lockout_datetime  datetime   null,
    lockout_ip        text       null,
    profile_img       text       null
);";

$sql10 ="create table visitors
(
    visitor_id  int auto_increment
        primary key,
    ip_addr     text     null,
    internet_ip text     null,
    protocol    text     null,
    HTTPS       text     null,
    port        text     null,
    page        text     null,
    timestamp   datetime null
);";

$sql11 ="create table work_tickets
(
    TNum              int auto_increment
        primary key,
    creator           text     not null,
    category          int      null,
    email             text     null,
    phone             text     null,
    cell_phone_svc    text     null,
    address           text     null,
    assignee_id       int      null,
    assignee          text     null,
    date_assigned     datetime null,
    status            text     null,
    description       longtext null,
    opened            datetime null,
    closed            datetime null,
    open_to_assigned  text     null,
    opened_to_closed  text     null,
    total_time_open   text     null,
    total_time_worked time     null
);";
$tables = array($sql,$sql1,$sql2,$sql3,$sql4,$sql5,$sql6,$sql7,$sql8,$sql9,$sql10,$sql11);


function newuser($password, $conn)
{
    $password1 = password_hash($password, PASSWORD_DEFAULT);



        $sql = "insert into users (lname, fname, usrname, password, email, ticket_count, last_login, failed_logins, password_last_set, admin, locked_out) values ('User', 'Admin', 'Admin', '$password1', 'team1@adm.com','0', CURRENT_TIMESTAMP(), '0', CURRENT_TIMESTAMP(), '1', '0');";


        if (!$conn->query($sql)) {
            return "<br> <h3>Problem Adding Administrator"  . $conn->error ."</h3>";
        } else {

            $conn->close();
            return "<br> <h3>Administrator Created</h3><br><h1>Username: Admin</h1><br><h1>Password: $password</h1>";
        }

}





function create_tables ($query, $conn){
    $errors = 0;
    $tables_issues = array();
    $index = 0;
    foreach ($query as $sql){
        if(!$conn->query($sql)){
            $errors += 1;
            array_push($tables_issues, $index . ">"  . $conn->error);
        }
        $index += 1;
    }
    $conn->close();
    if($errors > 0){
        $result ="<h2>Something when wrong, Alternatively the MySQL script can be run on the host with the DB</h2><h3>Issues with the following tables:</h3>";
        foreach ($tables_issues as $i){
            $result .= "<br><p>$i</p>";
        }
        return $result;
    } else {

    return "<h2>Success, no issues</h2>";}
}

